import React, { useState } from 'react';
import { X, Mail, Lock, User as UserIcon, Phone, CheckCircle, Sparkles, Shield, LogOut } from 'lucide-react';
import { User } from '../types';
import { STORE_CONFIG } from '../data/mockData';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  onLoginSuccess: (user: User) => void;
  onLogout: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLoginSuccess,
  onLogout,
}) => {
  if (!isOpen) return null;

  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [oauthDialog, setOauthDialog] = useState<'google' | 'facebook' | null>(null);

  // Email / Password Form Submit
  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      const user: User = {
        id: `user-${Date.now()}`,
        name: tab === 'register' ? name : (email.split('@')[0] || 'Khách Hàng'),
        email,
        phone: phone || undefined,
        provider: 'email',
        role: email.includes('admin') || email.includes('duynhat') ? 'admin' : 'customer',
        loyaltyPoints: 100,
        createdAt: new Date().toISOString(),
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
      };
      onLoginSuccess(user);
      onClose();
    }, 600);
  };

  // Google OAuth Flow
  const handleGoogleLogin = () => {
    setOauthDialog('google');
  };

  const confirmGoogleOAuth = (selectedEmail: string, selectedName: string) => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setOauthDialog(null);
      const googleUser: User = {
        id: 'google-user-01',
        name: selectedName,
        email: selectedEmail,
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
        provider: 'google',
        role: selectedEmail.includes('duynhat') ? 'admin' : 'customer',
        loyaltyPoints: 250,
        createdAt: new Date().toISOString(),
        savedAddresses: ['154 Nguyễn Văn Linh, P. Nam Dương, Q. Hải Châu, TP. Đà Nẵng'],
      };
      onLoginSuccess(googleUser);
      onClose();
    }, 700);
  };

  // Facebook OAuth Flow
  const handleFacebookLogin = () => {
    setOauthDialog('facebook');
  };

  const confirmFacebookOAuth = (fbName: string) => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setOauthDialog(null);
      const fbUser: User = {
        id: 'fb-user-01',
        name: fbName,
        email: 'duynhat.facebook@auth.vn',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
        provider: 'facebook',
        role: 'admin',
        loyaltyPoints: 300,
        createdAt: new Date().toISOString(),
        savedAddresses: ['Nguyễn Văn Linh, Nam Dương, Đà Nẵng'],
      };
      onLoginSuccess(fbUser);
      onClose();
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div 
        className="relative bg-white rounded-3xl max-w-md w-full shadow-2xl border border-neutral-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="btn-close-auth-modal"
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* GOOGLE OAUTH POPUP SIMULATION */}
        {oauthDialog === 'google' && (
          <div className="p-6 space-y-5">
            <div className="flex items-center gap-3 border-b border-neutral-100 pb-3">
              <svg className="w-6 h-6" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <div>
                <h3 className="font-bold text-sm text-neutral-900">Đăng nhập bằng Google</h3>
                <p className="text-[11px] text-neutral-500">Liên kết tài khoản xác thực</p>
              </div>
            </div>

            <p className="text-xs text-neutral-600">
              Chọn tài khoản Google của bạn để đăng nhập vào <strong>Nhất & Tùng Boutique</strong>:
            </p>

            <div className="space-y-2">
              {/* Account 1: User default email */}
              <button
                type="button"
                onClick={() => confirmGoogleOAuth('duynhatvoff55@gmail.com', 'Võ Duy Nhất')}
                className="w-full p-3 rounded-xl border border-neutral-200 hover:border-[#8C6D37] hover:bg-[#FAF8F5] flex items-center gap-3 text-left transition-all group"
              >
                <div className="w-9 h-9 rounded-full bg-[#1A1A1A] text-[#C9A96E] font-bold flex items-center justify-center text-xs">
                  VDN
                </div>
                <div className="flex-1">
                  <span className="font-bold text-xs text-neutral-900 block group-hover:text-[#8C6D37]">
                    Võ Duy Nhất (Chủ shop)
                  </span>
                  <span className="text-[11px] text-neutral-500">duynhatvoff55@gmail.com</span>
                </div>
                <CheckCircle className="w-4 h-4 text-emerald-600" />
              </button>

              {/* Account 2: Manager */}
              <button
                type="button"
                onClick={() => confirmGoogleOAuth('phanthanh.tung.dn@gmail.com', 'Phan Thanh Tùng')}
                className="w-full p-3 rounded-xl border border-neutral-200 hover:border-[#8C6D37] hover:bg-[#FAF8F5] flex items-center gap-3 text-left transition-all group"
              >
                <div className="w-9 h-9 rounded-full bg-blue-900 text-white font-bold flex items-center justify-center text-xs">
                  PTT
                </div>
                <div className="flex-1">
                  <span className="font-bold text-xs text-neutral-900 block group-hover:text-[#8C6D37]">
                    Phan Thanh Tùng (Quản lý)
                  </span>
                  <span className="text-[11px] text-neutral-500">phanthanh.tung.dn@gmail.com</span>
                </div>
                <CheckCircle className="w-4 h-4 text-emerald-600" />
              </button>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setOauthDialog(null)}
                className="text-xs text-neutral-500 hover:text-neutral-900 px-3 py-1.5"
              >
                Hủy bỏ
              </button>
            </div>
          </div>
        )}

        {/* FACEBOOK OAUTH POPUP SIMULATION */}
        {oauthDialog === 'facebook' && (
          <div className="p-6 space-y-5">
            <div className="flex items-center gap-3 border-b border-neutral-100 pb-3">
              <div className="w-6 h-6 rounded-full bg-[#1877F2] text-white flex items-center justify-center font-bold text-xs">
                f
              </div>
              <div>
                <h3 className="font-bold text-sm text-neutral-900">Đăng nhập với Facebook</h3>
                <p className="text-[11px] text-neutral-500">Facebook Login OAuth</p>
              </div>
            </div>

            <p className="text-xs text-neutral-600">
              Cửa hàng sẽ nhận thông tin tên và ảnh đại diện công khai từ Facebook của bạn:
            </p>

            <div className="space-y-2">
              <button
                type="button"
                onClick={() => confirmFacebookOAuth('Võ Duy Nhất')}
                className="w-full p-3 rounded-xl border border-neutral-200 hover:border-[#1877F2] hover:bg-blue-50/50 flex items-center gap-3 text-left transition-all group"
              >
                <div className="w-9 h-9 rounded-full bg-[#1877F2] text-white font-bold flex items-center justify-center text-xs">
                  FB
                </div>
                <div className="flex-1">
                  <span className="font-bold text-xs text-neutral-900 block group-hover:text-[#1877F2]">
                    Tiếp tục dưới tên Võ Duy Nhất
                  </span>
                  <span className="text-[11px] text-neutral-500">Facebook ID: @duynhatvo</span>
                </div>
              </button>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setOauthDialog(null)}
                className="text-xs text-neutral-500 hover:text-neutral-900 px-3 py-1.5"
              >
                Hủy bỏ
              </button>
            </div>
          </div>
        )}

        {/* LOGGED IN USER PROFILE VIEW */}
        {!oauthDialog && currentUser && (
          <div className="p-6 space-y-5">
            <div className="text-center space-y-3">
              <img
                src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}
                alt={currentUser.name}
                className="w-20 h-20 rounded-full mx-auto object-cover border-2 border-[#C9A96E] shadow-md"
              />
              <div>
                <h3 className="font-serif text-xl font-bold text-neutral-900">{currentUser.name}</h3>
                <p className="text-xs text-neutral-500">{currentUser.email}</p>
                <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-[#F4EDE2] text-[#8C6D37] border border-[#E7DAC7]">
                  {currentUser.role === 'admin' ? '⭐ Quản Trị Viên (Admin)' : '💎 Thành Viên Thân Thiết'}
                </span>
              </div>
            </div>

            {/* Member Stats */}
            <div className="grid grid-cols-2 gap-3 bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#EAE6DF] text-center">
              <div>
                <span className="text-[10px] text-neutral-400 block uppercase font-bold">Điểm tích lũy</span>
                <span className="text-lg font-bold text-[#8C6D37]">{currentUser.loyaltyPoints} pts</span>
              </div>
              <div>
                <span className="text-[10px] text-neutral-400 block uppercase font-bold">Ưu đãi giảm</span>
                <span className="text-lg font-bold text-emerald-700">10% VIP</span>
              </div>
            </div>

            <div className="space-y-2 text-xs text-neutral-600">
              <p>• Địa chỉ shop liên kết: <strong>{STORE_CONFIG.address}, {STORE_CONFIG.ward}, {STORE_CONFIG.city}</strong></p>
              <p>• Hotline hỗ trợ: <strong>{STORE_CONFIG.phone}</strong> (Zalo: {STORE_CONFIG.zalo})</p>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 bg-[#1A1A1A] text-white text-xs font-semibold rounded-xl hover:bg-neutral-800 transition-colors"
              >
                Đóng & Tiếp Tục Mua Sắm
              </button>
              <button
                type="button"
                onClick={() => {
                  onLogout();
                  onClose();
                }}
                className="w-full py-2.5 text-rose-600 hover:bg-rose-50 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <LogOut className="w-4 h-4" />
                <span>Đăng Xuất Tài Khoản</span>
              </button>
            </div>
          </div>
        )}

        {/* AUTH FORM (LOGIN / REGISTER) */}
        {!oauthDialog && !currentUser && (
          <div className="p-6 sm:p-8 space-y-6">
            {/* Header Brand */}
            <div className="text-center">
              <span className="font-display font-black text-2xl tracking-[0.2em] text-neutral-900 block">
                LUXURY
              </span>
              <span className="text-[10px] font-sans tracking-widest text-[#8C6D37] uppercase font-bold">
                Tài Khoản Mua Sắm & Tích Điểm Thành Viên
              </span>
            </div>

            {/* Tab switcher */}
            <div className="flex border-b border-neutral-200 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setTab('login')}
                className={`flex-1 pb-2.5 border-b-2 text-center transition-colors ${
                  tab === 'login'
                    ? 'border-[#1A1A1A] text-neutral-900'
                    : 'border-transparent text-neutral-400 hover:text-neutral-700'
                }`}
              >
                Đăng Nhập
              </button>
              <button
                type="button"
                onClick={() => setTab('register')}
                className={`flex-1 pb-2.5 border-b-2 text-center transition-colors ${
                  tab === 'register'
                    ? 'border-[#1A1A1A] text-neutral-900'
                    : 'border-transparent text-neutral-400 hover:text-neutral-700'
                }`}
              >
                Đăng Ký Mới
              </button>
            </div>

            {/* Social Logins */}
            <div className="space-y-2.5">
              {/* Google Button */}
              <button
                id="btn-login-google"
                type="button"
                onClick={handleGoogleLogin}
                className="w-full py-2.5 px-4 rounded-xl border border-neutral-300 hover:bg-neutral-50 text-xs font-semibold text-neutral-800 flex items-center justify-center gap-3 transition-colors shadow-sm"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Tiếp tục với tài khoản Google</span>
              </button>

              {/* Facebook Button */}
              <button
                id="btn-login-facebook"
                type="button"
                onClick={handleFacebookLogin}
                className="w-full py-2.5 px-4 rounded-xl bg-[#1877F2] hover:bg-[#166fe5] text-white text-xs font-semibold flex items-center justify-center gap-3 transition-colors shadow-sm"
              >
                <div className="w-4 h-4 rounded-full bg-white text-[#1877F2] flex items-center justify-center font-bold text-[10px]">
                  f
                </div>
                <span>Tiếp tục với Facebook (Võ Duy Nhất)</span>
              </button>
            </div>

            <div className="flex items-center gap-3 text-xs text-neutral-400">
              <div className="h-px bg-neutral-200 flex-1" />
              <span>Hoặc qua Email</span>
              <div className="h-px bg-neutral-200 flex-1" />
            </div>

            {/* Email / Password Form */}
            <form onSubmit={handleAuthSubmit} className="space-y-3.5">
              {tab === 'register' && (
                <div>
                  <label className="text-xs font-semibold text-neutral-700 block mb-1">
                    Họ và Tên
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Nguyễn Văn A"
                      className="w-full pl-9 pr-3.5 py-2 text-xs border border-neutral-300 rounded-xl outline-none focus:border-[#8C6D37]"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="text-xs font-semibold text-neutral-700 block mb-1">
                  Địa Chỉ Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="email@example.com"
                    className="w-full pl-9 pr-3.5 py-2 text-xs border border-neutral-300 rounded-xl outline-none focus:border-[#8C6D37]"
                  />
                </div>
              </div>

              {tab === 'register' && (
                <div>
                  <label className="text-xs font-semibold text-neutral-700 block mb-1">
                    Số Điện Thoại
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="0905xxxxxx"
                      className="w-full pl-9 pr-3.5 py-2 text-xs border border-neutral-300 rounded-xl outline-none focus:border-[#8C6D37]"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="text-xs font-semibold text-neutral-700 block mb-1">
                  Mật Khẩu
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3.5 py-2 text-xs border border-neutral-300 rounded-xl outline-none focus:border-[#8C6D37]"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-[#1A1A1A] hover:bg-[#333] text-white font-semibold text-xs rounded-xl transition-all shadow-md mt-2 disabled:opacity-50"
              >
                {isLoading
                  ? 'Đang xử lý...'
                  : tab === 'login'
                  ? 'Đăng Nhập Tài Khoản'
                  : 'Tạo Tài Khoản & Nhận 100 Điểm'}
              </button>
            </form>

            <div className="text-center text-[11px] text-neutral-500">
              Bằng việc đăng ký, bạn đồng ý với chính sách bảo mật của Nhất & Tùng Boutique.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
