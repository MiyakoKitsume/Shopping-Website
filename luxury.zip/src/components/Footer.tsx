import React from 'react';
import { MapPin, Phone, MessageCircle, QrCode, ShieldCheck, Heart, Sparkles } from 'lucide-react';
import { STORE_CONFIG } from '../data/mockData';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0D0D0D] text-[#E5E0D8] border-t border-neutral-800 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-neutral-800/80">
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="font-display font-black text-2xl tracking-[0.2em] text-white">
                LUXURY
              </span>
              <span className="text-[9px] font-sans font-bold bg-[#C9A96E] text-[#111111] px-2 py-0.5 rounded tracking-widest uppercase">
                BOUTIQUE
              </span>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Cửa hàng thời trang cao cấp phong cách hiện đại, thanh lịch tại trung tâm Đà Nẵng. Chuyên các sản phẩm chuẩn form, chất liệu cotton & lụa cao cấp cho người Việt.
            </p>
            <div className="text-xs text-neutral-400 space-y-1 pt-1">
              <p>• Hotline / Zalo: <strong className="text-[#C9A96E]">{STORE_CONFIG.phone}</strong></p>
              <p>• Giờ mở cửa: <strong className="text-white">{STORE_CONFIG.openingHours}</strong></p>
            </div>
          </div>

          {/* Contact & Address */}
          <div className="space-y-4">
            <h4 className="font-bold text-xs uppercase tracking-widest text-[#C9A96E]">
              Địa Chỉ & Liên Hệ
            </h4>
            <div className="space-y-2.5 text-xs text-neutral-300">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#C9A96E] flex-shrink-0 mt-0.5" />
                <span>{STORE_CONFIG.address}, {STORE_CONFIG.ward}, {STORE_CONFIG.city}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#C9A96E] flex-shrink-0" />
                <span>Hotline: <strong className="text-white">{STORE_CONFIG.phone}</strong></span>
              </div>
              <div className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 text-[#C9A96E] flex-shrink-0" />
                <span>Zalo: <strong className="text-white">{STORE_CONFIG.zalo}</strong></span>
              </div>
              <div className="flex items-center gap-2.5">
                <span className="w-4 h-4 text-[#C9A96E] font-bold text-center">f</span>
                <span>Fanpage: <strong className="text-white">LUXURY Boutique Đà Nẵng</strong></span>
              </div>
            </div>
          </div>

          {/* MBBank Payment Info */}
          <div className="space-y-4">
            <h4 className="font-bold text-xs uppercase tracking-widest text-[#C9A96E]">
              Thanh Toán Qua VietQR
            </h4>
            <div className="bg-[#161616] p-4 rounded-2xl border border-neutral-800 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Ngân hàng:</span>
                <span className="font-bold text-white">MBBank Quân Đội</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Số tài khoản:</span>
                <span className="font-mono font-bold text-[#C9A96E]">{STORE_CONFIG.bankAccountNumber}</span>
              </div>
              <div className="text-[11px] text-emerald-400 pt-2 border-t border-neutral-800 text-center font-medium">
                ✓ Quét mã QR tự động thanh toán
              </div>
            </div>
          </div>

          {/* Policies & Guarantees */}
          <div className="space-y-4">
            <h4 className="font-bold text-xs uppercase tracking-widest text-[#C9A96E]">
              Chính Sách & Cam Kết
            </h4>
            <ul className="text-xs text-neutral-400 space-y-2.5">
              <li className="flex items-center gap-2.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                <span>Đổi size trong 7 ngày miễn phí</span>
              </li>
              <li className="flex items-center gap-2.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                <span>Kiểm tra hàng trước khi nhận</span>
              </li>
              <li className="flex items-center gap-2.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                <span>Giao hàng hỏa tốc tại Đà Nẵng</span>
              </li>
              <li className="flex items-center gap-2.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                <span>Miễn phí ship cho đơn từ 499.000₫</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <p>© 2026 LUXURY • Cửa hàng thời trang cao cấp Đà Nẵng. Bảo lưu mọi quyền.</p>
          <div className="flex items-center gap-2">
            <span>Hotline hỗ trợ:</span>
            <strong className="text-neutral-300 font-mono">{STORE_CONFIG.phone}</strong>
          </div>
        </div>
      </div>
    </footer>
  );
};
