import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Heart, 
  User as UserIcon, 
  Phone, 
  MapPin, 
  LayoutDashboard, 
  Store, 
  Menu, 
  X,
  Sparkles,
  LogOut
} from 'lucide-react';
import { STORE_CONFIG } from '../data/mockData';
import { User, CartItem, Product } from '../types';

interface HeaderProps {
  currentView: 'store' | 'admin';
  onViewChange: (view: 'store' | 'admin') => void;
  cartItems: CartItem[];
  wishlist: Product[];
  currentUser: User | null;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenAuth: () => void;
  onLogout: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onCategorySelect?: (cat: any) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onViewChange,
  cartItems,
  wishlist,
  currentUser,
  onOpenCart,
  onOpenWishlist,
  onOpenAuth,
  onLogout,
  searchQuery,
  onSearchChange,
  onCategorySelect,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#E8E6E1] transition-all duration-200">
      {/* Top Luxury Announcement Bar */}
      <div className="bg-[#111111] text-[#F3EFE6] px-4 sm:px-8 py-2.5 text-xs border-b border-[#242424]">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2.5">
          <div className="flex items-center gap-2.5 font-medium tracking-wide">
            <span className="inline-flex items-center justify-center bg-[#C9A96E] text-[#111111] text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              LUXURY BOUTIQUE
            </span>
            <span className="hidden md:inline text-neutral-300">
              Cửa Hàng Thời Trang Cao Cấp Đà Nẵng • Miễn phí ship nội thành từ 499k • Quét VietQR MBBank 24/7
            </span>
            <span className="md:hidden text-neutral-300">
              Hotline: {STORE_CONFIG.phone} • {STORE_CONFIG.address}, Đà Nẵng
            </span>
          </div>

          <div className="flex items-center gap-5 text-neutral-300 text-xs">
            <a 
              href={`tel:${STORE_CONFIG.phone}`} 
              className="flex items-center gap-1.5 hover:text-[#C9A96E] transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-[#C9A96E]" />
              <span className="font-semibold text-white tracking-wide">{STORE_CONFIG.phone}</span>
            </a>
            <span className="text-neutral-700 hidden sm:inline">|</span>
            <div className="hidden sm:flex items-center gap-1.5 text-neutral-300">
              <MapPin className="w-3.5 h-3.5 text-[#C9A96E]" />
              <span>{STORE_CONFIG.address}, Nam Dương, Đà Nẵng</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 sm:h-22 gap-6">
          {/* Mobile Menu Button */}
          <button
            id="btn-mobile-menu"
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2.5 rounded-xl text-neutral-700 hover:bg-neutral-100 transition-colors"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          {/* Logo & Brand Identity */}
          <div 
            onClick={() => { onViewChange('store'); }}
            className="cursor-pointer flex flex-col items-start select-none group"
          >
            <div className="flex items-center gap-2.5">
              <span className="font-display font-black text-2xl sm:text-3xl tracking-[0.22em] text-[#111111] group-hover:text-[#8C6D37] transition-colors">
                LUXURY
              </span>
              <span className="text-[9px] font-sans font-extrabold bg-[#111111] text-[#C9A96E] px-2 py-0.5 rounded tracking-widest uppercase border border-[#C9A96E]/40">
                BOUTIQUE
              </span>
            </div>
            <span className="text-[11px] font-sans font-medium tracking-wider text-neutral-400 uppercase">
              Thời Trang Cao Cấp • Đà Nẵng
            </span>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-8">
            <button
              onClick={() => {
                onViewChange('store');
                if (onCategorySelect) onCategorySelect('all');
              }}
              className={`text-sm font-medium tracking-wide transition-colors py-2 border-b-2 ${
                currentView === 'store' && !searchQuery
                  ? 'text-[#1A1A1A] border-[#1A1A1A]' 
                  : 'text-neutral-600 border-transparent hover:text-[#1A1A1A]'
              }`}
            >
              Tất Cả Sản Phẩm
            </button>
            <button
              onClick={() => {
                onViewChange('store');
                if (onCategorySelect) onCategorySelect('t-shirt');
              }}
              className="text-sm font-medium tracking-wide text-neutral-600 hover:text-[#1A1A1A] transition-colors py-2"
            >
              Áo Thun & Polo
            </button>
            <button
              onClick={() => {
                onViewChange('store');
                if (onCategorySelect) onCategorySelect('shirt');
              }}
              className="text-sm font-medium tracking-wide text-neutral-600 hover:text-[#1A1A1A] transition-colors py-2"
            >
              Sơ Mi & Đầm
            </button>
            <button
              onClick={() => {
                onViewChange('store');
                if (onCategorySelect) onCategorySelect('jeans');
              }}
              className="text-sm font-medium tracking-wide text-neutral-600 hover:text-[#1A1A1A] transition-colors py-2"
            >
              Quần Jean & Tây
            </button>
            <button
              onClick={() => {
                onViewChange('store');
                if (onCategorySelect) onCategorySelect('jacket');
              }}
              className="text-sm font-medium tracking-wide text-neutral-600 hover:text-[#1A1A1A] transition-colors py-2"
            >
              Áo Khoác
            </button>
          </nav>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex items-center relative max-w-xs w-full">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 pointer-events-none" />
            <input
              id="input-search-header"
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Tìm áo thun, sơ mi, jean..."
              className="w-full pl-9 pr-4 py-2 text-sm bg-neutral-100/80 hover:bg-neutral-100 focus:bg-white border border-transparent focus:border-[#C9A96E] rounded-full outline-none transition-all placeholder:text-neutral-400"
            />
            {searchQuery && (
              <button 
                onClick={() => onSearchChange('')}
                className="absolute right-3 text-neutral-400 hover:text-neutral-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Actions & User Section */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* View Mode Switcher: Store vs Admin Dashboard */}
            <button
              id="btn-toggle-admin-view"
              type="button"
              onClick={() => onViewChange(currentView === 'store' ? 'admin' : 'store')}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-full transition-all ${
                currentView === 'admin'
                  ? 'bg-[#1A1A1A] text-white ring-2 ring-[#C9A96E]/50 shadow-sm'
                  : 'bg-[#F4EDE2] text-[#8C6D37] hover:bg-[#EBDFCF] border border-[#E7DAC7]'
              }`}
              title={currentView === 'store' ? 'Vào bảng điều khiển quản lý shop' : 'Quay lại xem cửa hàng'}
            >
              {currentView === 'store' ? (
                <>
                  <LayoutDashboard className="w-3.5 h-3.5 text-[#8C6D37]" />
                  <span className="hidden sm:inline">Quản Lý Shop</span>
                </>
              ) : (
                <>
                  <Store className="w-3.5 h-3.5 text-white" />
                  <span className="hidden sm:inline">Xem Cửa Hàng</span>
                </>
              )}
            </button>

            {/* Mobile Search Toggle */}
            <button
              id="btn-search-mobile-toggle"
              type="button"
              onClick={() => setSearchOpen(!searchOpen)}
              className="md:hidden p-2 rounded-full text-neutral-700 hover:bg-neutral-100 transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Wishlist Button */}
            <button
              id="btn-open-wishlist"
              type="button"
              onClick={onOpenWishlist}
              className="relative p-2 rounded-full text-neutral-700 hover:bg-neutral-100 transition-colors"
              title="Danh sách yêu thích"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Shopping Cart Drawer Trigger */}
            <button
              id="btn-open-cart"
              type="button"
              onClick={onOpenCart}
              className="relative flex items-center gap-2 p-2 sm:px-3 sm:py-2 rounded-full bg-neutral-900 text-white hover:bg-neutral-800 transition-colors shadow-sm"
              title="Giỏ hàng"
            >
              <ShoppingBag className="w-5 h-5 text-[#E7DAC7]" />
              <span className="hidden sm:inline text-xs font-semibold tracking-wider">
                GIỎ HÀNG
              </span>
              {totalCartCount > 0 && (
                <span className="bg-[#C9A96E] text-neutral-900 text-xs font-bold px-2 py-0.5 rounded-full">
                  {totalCartCount}
                </span>
              )}
            </button>

            {/* User Account / Login */}
            {currentUser ? (
              <div className="relative flex items-center gap-2 pl-2 border-l border-neutral-200">
                <div 
                  onClick={onOpenAuth}
                  className="flex items-center gap-2 cursor-pointer group"
                >
                  <img 
                    src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'} 
                    alt={currentUser.name}
                    className="w-8 h-8 rounded-full object-cover border border-[#C9A96E]"
                  />
                  <div className="hidden lg:flex flex-col text-left">
                    <span className="text-xs font-bold text-neutral-800 line-clamp-1 group-hover:text-[#8C6D37]">
                      {currentUser.name}
                    </span>
                    <span className="text-[10px] text-neutral-500 capitalize">
                      {currentUser.provider === 'google' ? 'Google' : currentUser.provider === 'facebook' ? 'Facebook' : 'Thành viên'}
                    </span>
                  </div>
                </div>
                <button
                  id="btn-user-logout"
                  type="button"
                  onClick={onLogout}
                  className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-full transition-colors"
                  title="Đăng xuất"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                id="btn-open-auth-modal"
                type="button"
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-800 hover:text-neutral-900 hover:bg-neutral-100 rounded-full border border-neutral-300 transition-colors"
              >
                <UserIcon className="w-4 h-4" />
                <span className="hidden sm:inline">Đăng nhập</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Search Bar Expand */}
        {searchOpen && (
          <div className="md:hidden pb-3 pt-1">
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-3 pointer-events-none" />
              <input
                id="input-search-mobile"
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Tìm quần áo, áo thun, sơ mi..."
                className="w-full pl-9 pr-4 py-2.5 text-sm bg-neutral-100 border border-neutral-200 rounded-lg outline-none focus:border-[#C9A96E]"
                autoFocus
              />
            </div>
          </div>
        )}
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-neutral-200 px-4 py-4 space-y-3">
          <div className="grid grid-cols-2 gap-2 text-sm">
            <button
              onClick={() => {
                onViewChange('store');
                if (onCategorySelect) onCategorySelect('all');
                setMobileMenuOpen(false);
              }}
              className="text-left px-3 py-2 bg-neutral-50 rounded-lg font-medium text-neutral-800"
            >
              👕 Tất Cả Sản Phẩm
            </button>
            <button
              onClick={() => {
                onViewChange('store');
                if (onCategorySelect) onCategorySelect('t-shirt');
                setMobileMenuOpen(false);
              }}
              className="text-left px-3 py-2 bg-neutral-50 rounded-lg font-medium text-neutral-800"
            >
              ✨ Áo Thun & Polo
            </button>
            <button
              onClick={() => {
                onViewChange('store');
                if (onCategorySelect) onCategorySelect('shirt');
                setMobileMenuOpen(false);
              }}
              className="text-left px-3 py-2 bg-neutral-50 rounded-lg font-medium text-neutral-800"
            >
              👔 Sơ Mi & Đầm
            </button>
            <button
              onClick={() => {
                onViewChange('store');
                if (onCategorySelect) onCategorySelect('jeans');
                setMobileMenuOpen(false);
              }}
              className="text-left px-3 py-2 bg-neutral-50 rounded-lg font-medium text-neutral-800"
            >
              👖 Quần Jean & Tây
            </button>
          </div>

          <div className="pt-3 border-t border-neutral-100 flex flex-col gap-2 text-xs text-neutral-600">
            <div className="flex items-center gap-2">
              <span className="font-bold text-neutral-900">Showroom:</span> <span className="text-neutral-700">LUXURY Fashion Đà Nẵng</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-[#C9A96E]" />
              <span>{STORE_CONFIG.address}, {STORE_CONFIG.ward}, {STORE_CONFIG.city}</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
