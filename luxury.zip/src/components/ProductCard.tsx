import React from 'react';
import { Heart, ShoppingBag, Eye, Star, Check } from 'lucide-react';
import { Product } from '../types';
import { formatVND } from '../lib/utils';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onQuickAddToCart: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  onToggleWishlist,
  onQuickView,
  onQuickAddToCart,
}) => {
  const discountPercent = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="group relative flex flex-col bg-white rounded-2xl border border-[#EAE6DF] overflow-hidden transition-all duration-300 hover:shadow-xl hover:border-[#DFCDB7]">
      {/* Product Image Container */}
      <div className="relative aspect-[3/4] w-full overflow-hidden bg-neutral-100">
        <img
          src={product.images[0]}
          alt={product.name}
          className="h-full w-full object-cover object-center transform group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Badges Top Left */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {product.isNew && (
            <span className="bg-[#1A1A1A] text-[#F3EFE6] text-[10px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full shadow-sm">
              Mới Về
            </span>
          )}
          {discountPercent > 0 && (
            <span className="bg-rose-600 text-white text-[10px] font-bold tracking-wider px-2 py-0.5 rounded-full shadow-sm">
              -{discountPercent}%
            </span>
          )}
          {product.isBestSeller && (
            <span className="bg-[#8C6D37] text-white text-[10px] font-bold tracking-wider px-2 py-0.5 rounded-full shadow-sm">
              Bán Chạy
            </span>
          )}
        </div>

        {/* Wishlist Button Top Right */}
        <button
          id={`btn-wishlist-${product.id}`}
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-colors z-10 ${
            isWishlisted
              ? 'bg-rose-50 text-rose-600'
              : 'bg-white/80 text-neutral-600 hover:bg-white hover:text-rose-600'
          }`}
          title={isWishlisted ? 'Bỏ khỏi yêu thích' : 'Lưu vào yêu thích'}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>

        {/* Action Overlay Button on Hover */}
        <div className="absolute inset-x-3 bottom-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10">
          <button
            id={`btn-quickview-${product.id}`}
            type="button"
            onClick={() => onQuickView(product)}
            className="flex-1 bg-white/95 hover:bg-white text-neutral-900 text-xs font-semibold py-2.5 px-3 rounded-xl shadow-lg flex items-center justify-center gap-1.5 transition-transform active:scale-95"
          >
            <Eye className="w-3.5 h-3.5 text-[#8C6D37]" />
            <span>Xem nhanh</span>
          </button>
          <button
            id={`btn-add-cart-${product.id}`}
            type="button"
            onClick={() => onQuickAddToCart(product)}
            className="bg-[#1A1A1A] hover:bg-[#333] text-white text-xs font-semibold p-2.5 rounded-xl shadow-lg flex items-center justify-center transition-transform active:scale-95"
            title="Thêm nhanh vào giỏ"
          >
            <ShoppingBag className="w-4 h-4 text-[#C9A96E]" />
          </button>
        </div>
      </div>

      {/* Product Information */}
      <div className="p-4 flex flex-col flex-grow justify-between space-y-3">
        <div>
          {/* Category & Rating */}
          <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
            <span className="uppercase tracking-wider font-medium text-[10px] text-[#8C6D37]">
              {product.categoryName}
            </span>
            <div className="flex items-center gap-1 text-amber-500 font-semibold text-[11px]">
              <Star className="w-3 h-3 fill-current" />
              <span>{product.rating}</span>
              <span className="text-neutral-400 font-normal">({product.reviewCount})</span>
            </div>
          </div>

          {/* Product Name */}
          <h3 
            onClick={() => onQuickView(product)}
            className="font-medium text-sm text-neutral-900 line-clamp-2 hover:text-[#8C6D37] cursor-pointer transition-colors"
          >
            {product.name}
          </h3>
        </div>

        {/* Sizes and Colors preview */}
        <div className="flex items-center justify-between pt-1 border-t border-neutral-100 text-xs">
          {/* Sizes */}
          <div className="flex items-center gap-1 text-[11px] text-neutral-500">
            <span>Size:</span>
            <div className="flex gap-1 font-semibold text-neutral-700">
              {product.sizes.slice(0, 3).map((s) => (
                <span key={s}>{s}</span>
              ))}
              {product.sizes.length > 3 && <span>+{product.sizes.length - 3}</span>}
            </div>
          </div>

          {/* Colors */}
          <div className="flex items-center gap-1">
            {product.colors.slice(0, 3).map((c, i) => (
              <span
                key={i}
                className="w-3 h-3 rounded-full border border-neutral-300"
                style={{ backgroundColor: c.hex }}
                title={c.name}
              />
            ))}
          </div>
        </div>

        {/* Price Row */}
        <div className="flex items-baseline justify-between pt-1">
          <div className="flex items-baseline gap-2">
            <span className="text-base font-bold text-neutral-900 font-sans">
              {formatVND(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-neutral-400 line-through">
                {formatVND(product.originalPrice)}
              </span>
            )}
          </div>
          
          <span className="text-[10px] text-emerald-700 font-medium bg-emerald-50 px-2 py-0.5 rounded">
            {product.stock > 0 ? `Còn ${product.stock}` : 'Hết hàng'}
          </span>
        </div>
      </div>
    </div>
  );
};
