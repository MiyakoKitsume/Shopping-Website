import React, { useState } from 'react';
import { 
  X, 
  Check, 
  Copy, 
  QrCode, 
  CreditCard, 
  Truck, 
  ShieldCheck, 
  Upload, 
  Sparkles,
  Phone,
  Printer,
  ChevronRight,
  Building
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CartItem, Order, PaymentMethod, User } from '../types';
import { STORE_CONFIG } from '../data/mockData';
import { formatVND, generateOrderCode, getVietQRUrl } from '../lib/utils';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  currentUser: User | null;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  currentUser,
  onOrderSuccess,
}) => {
  if (!isOpen) return null;

  // Form State
  const [customerName, setCustomerName] = useState(currentUser?.name || '');
  const [customerPhone, setCustomerPhone] = useState(currentUser?.phone || '');
  const [customerEmail, setCustomerEmail] = useState(currentUser?.email || '');
  const [customerAddress, setCustomerAddress] = useState('Nguyễn Văn Linh, P. Nam Dương');
  const [city, setCity] = useState('TP. Đà Nẵng');
  const [district, setDistrict] = useState('Quận Hải Châu');
  const [note, setNote] = useState('');
  
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('mbbank_qr');
  const [proofImage, setProofImage] = useState<string | null>(null);
  const [isCopiedText, setIsCopiedText] = useState<string | null>(null);
  
  // Checkout Process State
  const [orderCode] = useState(generateOrderCode());
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const shippingFee = subtotal >= 499000 || subtotal === 0 ? 0 : 25000;
  const totalAmount = subtotal + shippingFee;

  const vietQrUrl = getVietQRUrl(totalAmount, orderCode);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setIsCopiedText(label);
    setTimeout(() => setIsCopiedText(null), 2000);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProofImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim() || !customerAddress.trim()) {
      alert('Vui lòng điền đầy đủ Họ tên, Số điện thoại và Địa chỉ giao hàng.');
      return;
    }

    setIsSubmitting(true);

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderCode,
      createdAt: new Date().toLocaleString('vi-VN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      }),
      customerName,
      customerPhone,
      customerEmail,
      customerAddress,
      city,
      district,
      note,
      items: [...items],
      subtotal,
      discount: 0,
      shippingFee,
      totalAmount,
      paymentMethod,
      paymentStatus: paymentMethod === 'cod' ? 'pending' : 'paid',
      shippingStatus: 'processing',
      transferProofImage: proofImage || undefined,
      bankTransactionCode: paymentMethod !== 'cod' ? `MB-${Math.floor(100000 + Math.random() * 900000)}` : undefined,
    };

    setTimeout(() => {
      setIsSubmitting(false);
      setCompletedOrder(newOrder);
      onOrderSuccess(newOrder);
      
      // Fire celebration confetti
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#C9A96E', '#1A1A1A', '#8C6D37', '#22c55e']
      });
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 md:p-6 animate-fadeIn">
      <div 
        className="relative bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-neutral-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="btn-close-checkout-modal"
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* ORDER SUCCESS SCREEN */}
        {completedOrder ? (
          <div className="p-8 sm:p-12 text-center space-y-8">
            <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm border border-emerald-200">
              <Check className="w-10 h-10" />
            </div>

            <div className="space-y-2 max-w-lg mx-auto">
              <span className="text-xs font-bold text-[#8C6D37] uppercase tracking-widest block">
                Đặt Hàng Thành Công • LUXURY Boutique
              </span>
              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-neutral-900">
                Cảm ơn quý khách {completedOrder.customerName}!
              </h2>
              <p className="text-neutral-600 text-sm leading-relaxed">
                Mã đơn hàng của bạn là <strong className="text-neutral-900 bg-neutral-100 px-2.5 py-1 rounded-lg font-mono text-sm">{completedOrder.orderCode}</strong>.
                Nhân viên chăm sóc khách hàng LUXURY sẽ liên hệ xác nhận và điều phối giao hàng sớm nhất.
              </p>
            </div>

            {/* QR Scan Box on Receipt (If Bank Transfer or Customer Wants Quick QR Scan) */}
            {completedOrder.paymentMethod === 'mbbank_qr' && (
              <div className="bg-[#111111] text-white p-6 sm:p-7 rounded-3xl border border-[#C9A96E]/40 shadow-xl max-w-xl mx-auto text-left space-y-4">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div className="flex items-center gap-2.5">
                    <QrCode className="w-5 h-5 text-[#C9A96E]" />
                    <span className="text-xs font-bold text-[#E7DAC7] uppercase tracking-wider">Mã VietQR MBBank</span>
                  </div>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2.5 py-1 rounded-full font-mono font-bold">
                    Khớp Lệnh Tức Thì
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 items-center">
                  <div className="sm:col-span-5 bg-white p-3 rounded-2xl text-center shadow-md">
                    <img
                      src={vietQrUrl}
                      alt={`Mã QR Thanh Toán MBBank ${completedOrder.orderCode}`}
                      className="w-full aspect-square object-contain mx-auto"
                    />
                    <span className="text-[10px] font-semibold text-neutral-700 block mt-1.5 font-sans">
                      Quét mã bằng App Ngân hàng
                    </span>
                  </div>

                  <div className="sm:col-span-7 space-y-2.5 text-xs text-neutral-300">
                    <div className="bg-white/5 p-3 rounded-xl border border-white/10 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-neutral-400 block">Số tài khoản MB:</span>
                        <span className="font-mono font-bold text-sm text-[#C9A96E]">{STORE_CONFIG.bankAccountNumber}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => copyToClipboard(STORE_CONFIG.bankAccountNumber, 'stk_succ')}
                        className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-neutral-300 transition-colors"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="bg-white/5 p-3 rounded-xl border border-white/10 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-neutral-400 block">Số tiền:</span>
                        <span className="font-bold text-sm text-emerald-400">{formatVND(completedOrder.totalAmount)}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => copyToClipboard(completedOrder.totalAmount.toString(), 'amt_succ')}
                        className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-neutral-300 transition-colors"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="bg-white/5 p-3 rounded-xl border border-white/10 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-neutral-400 block">Nội dung chuyển khoản:</span>
                        <span className="font-mono font-bold text-xs text-[#E7DAC7]">THANHTOAN {completedOrder.orderCode}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => copyToClipboard(`THANHTOAN ${completedOrder.orderCode}`, 'nd_succ')}
                        className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-neutral-300 transition-colors"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Receipt Box */}
            <div className="bg-[#FAF8F5] p-6 sm:p-8 rounded-3xl border border-[#EAE6DF] text-left max-w-xl mx-auto space-y-5 text-xs">
              <div className="flex justify-between items-center border-b border-neutral-200 pb-3.5">
                <div>
                  <h4 className="font-bold text-sm text-neutral-900 font-display">HÓA ĐƠN ĐƠN HÀNG</h4>
                  <p className="text-neutral-500 text-[11px]">LUXURY Boutique Đà Nẵng</p>
                </div>
                <span className="bg-neutral-900 text-white font-bold px-3 py-1 rounded-full uppercase text-[10px] tracking-wider">
                  {completedOrder.paymentMethod === 'mbbank_qr' ? 'Thanh Toán VietQR' : 'Thanh Toán COD'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 text-neutral-600">
                <div>
                  <span className="text-neutral-400 block text-[11px]">Người nhận:</span>
                  <span className="font-semibold text-neutral-900 text-xs">{completedOrder.customerName} ({completedOrder.customerPhone})</span>
                </div>
                <div>
                  <span className="text-neutral-400 block text-[11px]">Địa chỉ nhận hàng:</span>
                  <span className="font-semibold text-neutral-900 text-xs">{completedOrder.customerAddress}, {completedOrder.city}</span>
                </div>
                <div>
                  <span className="text-neutral-400 block text-[11px]">Tổng thanh toán:</span>
                  <span className="font-bold text-base text-[#8C6D37]">{formatVND(completedOrder.totalAmount)}</span>
                </div>
                <div>
                  <span className="text-neutral-400 block text-[11px]">Hotline hỗ trợ:</span>
                  <span className="font-semibold text-neutral-900 text-xs">{STORE_CONFIG.phone}</span>
                </div>
              </div>

              {/* Items in receipt */}
              <div className="border-t border-neutral-200 pt-3.5 space-y-2.5">
                <p className="font-bold text-neutral-800">Sản phẩm đặt mua ({completedOrder.items.length}):</p>
                {completedOrder.items.map((it, i) => (
                  <div key={i} className="flex justify-between items-center text-neutral-600 py-1 border-b border-neutral-100 last:border-0">
                    <span>
                      {it.quantity}x {it.product.name} (Size {it.selectedSize} - {it.selectedColor.name})
                    </span>
                    <span className="font-medium text-neutral-900">{formatVND(it.product.price * it.quantity)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="px-6 py-3.5 rounded-2xl border border-neutral-300 text-neutral-700 text-xs font-semibold hover:bg-neutral-50 transition-colors flex items-center gap-2"
              >
                <Printer className="w-4 h-4" />
                <span>In Hóa Đơn</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="px-8 py-3.5 rounded-2xl bg-[#111111] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors shadow-md"
              >
                Tiếp Tục Mua Sắm
              </button>
            </div>
          </div>
        ) : (
          /* CHECKOUT FORM & MBBANK PAYMENT */
          <div className="p-6 sm:p-10">
            <div className="mb-8">
              <span className="text-xs font-bold text-[#8C6D37] uppercase tracking-widest block">
                Thanh Toán & Đặt Hàng
              </span>
              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-neutral-900 mt-1">
                Xác Nhận Đơn Hàng • Mã: <span className="font-mono text-[#8C6D37]">{orderCode}</span>
              </h2>
            </div>

            <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
              {/* Left Column: Customer Details (6 cols) */}
              <div className="lg:col-span-6 space-y-6">
                <div className="bg-white p-6 rounded-3xl border border-neutral-200 shadow-sm space-y-5">
                  <h3 className="font-bold text-sm text-neutral-900 flex items-center gap-2 border-b border-neutral-100 pb-3">
                    <Truck className="w-4 h-4 text-[#8C6D37]" />
                    <span>Thông Tin Nhận Hàng</span>
                  </h3>

                  {/* Name */}
                  <div>
                    <label className="text-xs font-semibold text-neutral-700 block mb-1.5">
                      Họ và Tên người nhận *
                    </label>
                    <input
                      id="input-customer-name"
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="VD: Nguyễn Văn An"
                      className="w-full px-4 py-3 text-xs bg-neutral-50 border border-neutral-200 rounded-2xl outline-none focus:border-[#8C6D37] focus:bg-white transition-all"
                    />
                  </div>

                  {/* Phone & Email */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-semibold text-neutral-700 block mb-1.5">
                        Số Điện Thoại (Zalo) *
                      </label>
                      <input
                        id="input-customer-phone"
                        type="tel"
                        required
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="VD: 0905123456"
                        className="w-full px-4 py-3 text-xs bg-neutral-50 border border-neutral-200 rounded-2xl outline-none focus:border-[#8C6D37] focus:bg-white transition-all"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-neutral-700 block mb-1.5">
                        Email (Nhận hóa đơn)
                      </label>
                      <input
                        id="input-customer-email"
                        type="email"
                        value={customerEmail}
                        onChange={(e) => setCustomerEmail(e.target.value)}
                        placeholder="email@example.com"
                        className="w-full px-4 py-3 text-xs bg-neutral-50 border border-neutral-200 rounded-2xl outline-none focus:border-[#8C6D37] focus:bg-white transition-all"
                      />
                    </div>
                  </div>

                  {/* Address & City */}
                  <div>
                    <label className="text-xs font-semibold text-neutral-700 block mb-1.5">
                      Địa Chỉ Nhà / Tên Đường *
                    </label>
                    <input
                      id="input-customer-address"
                      type="text"
                      required
                      value={customerAddress}
                      onChange={(e) => setCustomerAddress(e.target.value)}
                      placeholder="Số nhà, tên đường (VD: 154 Nguyễn Văn Linh)"
                      className="w-full px-4 py-3 text-xs bg-neutral-50 border border-neutral-200 rounded-2xl outline-none focus:border-[#8C6D37] focus:bg-white transition-all"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-semibold text-neutral-700 block mb-1.5">
                        Quận / Huyện
                      </label>
                      <select
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        className="w-full px-4 py-3 text-xs bg-neutral-50 border border-neutral-200 rounded-2xl outline-none focus:border-[#8C6D37] focus:bg-white transition-all"
                      >
                        <option value="Quận Hải Châu">Quận Hải Châu</option>
                        <option value="Quận Thanh Khê">Quận Thanh Khê</option>
                        <option value="Quận Sơn Trà">Quận Sơn Trà</option>
                        <option value="Quận Ngũ Hành Sơn">Quận Ngũ Hành Sơn</option>
                        <option value="Quận Cẩm Lệ">Quận Cẩm Lệ</option>
                        <option value="Quận Liên Chiểu">Quận Liên Chiểu</option>
                        <option value="Tỉnh thành khác">Tỉnh thành khác</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-neutral-700 block mb-1.5">
                        Tỉnh / Thành Phố
                      </label>
                      <input
                        type="text"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full px-4 py-3 text-xs bg-neutral-50 border border-neutral-200 rounded-2xl outline-none"
                      />
                    </div>
                  </div>

                  {/* Note */}
                  <div>
                    <label className="text-xs font-semibold text-neutral-700 block mb-1.5">
                      Ghi chú giao hàng
                    </label>
                    <textarea
                      rows={2}
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="VD: Giao giờ hành chính, gọi trước khi đến..."
                      className="w-full px-4 py-3 text-xs bg-neutral-50 border border-neutral-200 rounded-2xl outline-none focus:border-[#8C6D37] focus:bg-white transition-all"
                    />
                  </div>
                </div>

                {/* Store Hotline & Guarantee Box */}
                <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#EAE6DF] text-xs space-y-1.5 text-neutral-600">
                  <p className="font-bold text-neutral-900">Showroom LUXURY Đà Nẵng cam kết:</p>
                  <p>• Hotline & Zalo hỗ trợ: <a href={`tel:${STORE_CONFIG.phone}`} className="text-[#8C6D37] font-bold">{STORE_CONFIG.phone}</a></p>
                  <p>• Địa chỉ: {STORE_CONFIG.address}, {STORE_CONFIG.ward}, {STORE_CONFIG.city}</p>
                </div>
              </div>

              {/* Right Column: MBBank VietQR & Payment Selection (6 cols) */}
              <div className="lg:col-span-6 space-y-6">
                {/* Payment Methods */}
                <div>
                  <label className="text-xs font-bold text-neutral-900 uppercase tracking-wider block mb-3">
                    Chọn Phương Thức Thanh Toán
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('mbbank_qr')}
                      className={`p-4 rounded-2xl border text-left flex items-start gap-3 transition-all ${
                        paymentMethod === 'mbbank_qr'
                          ? 'border-[#8C6D37] bg-[#FAF8F5] ring-2 ring-[#C9A96E]/40 shadow-sm'
                          : 'border-neutral-200 bg-white hover:bg-neutral-50'
                      }`}
                    >
                      <div className="p-2 rounded-xl bg-[#FAF8F5] text-[#8C6D37] border border-[#E7DAC7]">
                        <QrCode className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-neutral-900 block">MBBank VietQR</span>
                        <span className="text-[11px] text-neutral-500">Quét mã QR tự động điền</span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cod')}
                      className={`p-4 rounded-2xl border text-left flex items-start gap-3 transition-all ${
                        paymentMethod === 'cod'
                          ? 'border-[#8C6D37] bg-[#FAF8F5] ring-2 ring-[#C9A96E]/40 shadow-sm'
                          : 'border-neutral-200 bg-white hover:bg-neutral-50'
                      }`}
                    >
                      <div className="p-2 rounded-xl bg-neutral-100 text-neutral-700 border border-neutral-200">
                        <Truck className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-neutral-900 block">Thanh toán COD</span>
                        <span className="text-[11px] text-neutral-500">Trả tiền mặt khi nhận hàng</span>
                      </div>
                    </button>
                  </div>
                </div>

                {/* MBBank VietQR Card */}
                {paymentMethod === 'mbbank_qr' && (
                  <div className="bg-[#111111] text-white p-6 sm:p-7 rounded-3xl border border-[#C9A96E]/40 shadow-xl space-y-5">
                    <div className="flex items-center justify-between border-b border-white/10 pb-3.5">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-[#C9A96E] text-[#111111] flex items-center justify-center font-black text-xs">
                          MB
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-[#E7DAC7]">Ngân Hàng MBBank Quân Đội</h4>
                          <p className="text-[10px] text-neutral-400">Tài khoản chính thức cửa hàng</p>
                        </div>
                      </div>
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2.5 py-1 rounded-full font-mono font-bold">
                        VietQR 24/7
                      </span>
                    </div>

                    {/* QR Code and Credentials */}
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 items-center">
                      {/* Real VietQR Image */}
                      <div className="sm:col-span-5 bg-white p-3 rounded-2xl text-center shadow-lg border border-neutral-100">
                        <img
                          src={vietQrUrl}
                          alt="Mã QR Thanh Toán MBBank"
                          className="w-full aspect-square object-contain mx-auto"
                        />
                        <span className="text-[10px] font-semibold text-neutral-700 block mt-2 font-sans">
                          Mở app ngân hàng quét mã
                        </span>
                      </div>

                      {/* Bank Details with 1-click Copy */}
                      <div className="sm:col-span-7 space-y-2.5 text-xs">
                        {/* Account Number */}
                        <div className="bg-white/5 p-3 rounded-2xl flex items-center justify-between border border-white/10">
                          <div>
                            <span className="text-[10px] text-neutral-400 block">Số tài khoản MBBank:</span>
                            <span className="font-mono font-bold text-sm text-[#C9A96E]">
                              {STORE_CONFIG.bankAccountNumber}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => copyToClipboard(STORE_CONFIG.bankAccountNumber, 'stk')}
                            className="p-2 bg-white/10 hover:bg-white/20 rounded-xl text-neutral-300 hover:text-white transition-colors"
                            title="Sao chép số tài khoản"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Amount */}
                        <div className="bg-white/5 p-3 rounded-2xl flex items-center justify-between border border-white/10">
                          <div>
                            <span className="text-[10px] text-neutral-400 block">Số tiền thanh toán:</span>
                            <span className="font-bold text-sm text-emerald-400">
                              {formatVND(totalAmount)}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => copyToClipboard(totalAmount.toString(), 'tien')}
                            className="p-2 bg-white/10 hover:bg-white/20 rounded-xl text-neutral-300 hover:text-white transition-colors"
                            title="Sao chép số tiền"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Transfer Content */}
                        <div className="bg-white/5 p-3 rounded-2xl flex items-center justify-between border border-white/10">
                          <div>
                            <span className="text-[10px] text-neutral-400 block">Nội dung chuyển khoản:</span>
                            <span className="font-mono font-bold text-xs text-[#E7DAC7]">
                              THANHTOAN {orderCode}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => copyToClipboard(`THANHTOAN ${orderCode}`, 'nd')}
                            className="p-2 bg-white/10 hover:bg-white/20 rounded-xl text-neutral-300 hover:text-white transition-colors"
                            title="Sao chép nội dung"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {isCopiedText && (
                          <div className="text-[10px] text-emerald-400 text-center font-medium bg-emerald-950/60 py-1.5 rounded-xl border border-emerald-800/50">
                            ✓ Đã sao chép vào bộ nhớ tạm!
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Screenshot Proof Uploader */}
                    <div className="pt-3 border-t border-white/10">
                      <label className="text-[11px] font-semibold text-neutral-300 block mb-2">
                        Đính kèm ảnh biên lai chuyển khoản (Tùy chọn):
                      </label>
                      <div className="flex items-center gap-3">
                        <label className="cursor-pointer px-4 py-2.5 bg-white/10 hover:bg-white/20 rounded-2xl text-xs text-neutral-200 border border-white/20 flex items-center gap-2 transition-colors">
                          <Upload className="w-3.5 h-3.5 text-[#C9A96E]" />
                          <span>{proofImage ? '✓ Đã đính kèm ảnh' : 'Chọn ảnh biên lai'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            className="hidden"
                          />
                        </label>
                        {proofImage && (
                          <img
                            src={proofImage}
                            alt="Biên lai thanh toán"
                            className="w-12 h-12 rounded-xl object-cover border-2 border-emerald-500 shadow"
                          />
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Order Summary Breakdown */}
                <div className="bg-[#FAF8F5] p-5 rounded-3xl border border-[#EAE6DF] space-y-3 text-xs text-neutral-600">
                  <div className="flex justify-between">
                    <span>Tổng tiền sản phẩm ({items.length} món):</span>
                    <span className="font-bold text-neutral-900">{formatVND(subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Phí vận chuyển:</span>
                    <span className="font-semibold text-emerald-700">
                      {shippingFee === 0 ? 'MIỄN PHÍ' : formatVND(shippingFee)}
                    </span>
                  </div>
                  <div className="flex justify-between text-base font-bold text-neutral-900 pt-3 border-t border-neutral-200">
                    <span>Tổng cộng:</span>
                    <span className="text-xl text-[#8C6D37]">{formatVND(totalAmount)}</span>
                  </div>
                </div>

                {/* Submit Button */}
                <button
                  id="btn-confirm-order"
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 px-6 rounded-2xl bg-[#111111] hover:bg-[#2A2A2A] text-white font-bold text-sm tracking-wider uppercase transition-all shadow-xl flex items-center justify-center gap-2 disabled:opacity-50 active:scale-[0.99]"
                >
                  {isSubmitting ? (
                    <span>Đang xử lý đơn hàng...</span>
                  ) : (
                    <>
                      <ShieldCheck className="w-5 h-5 text-[#C9A96E]" />
                      <span>Xác Nhận Đặt Hàng ({formatVND(totalAmount)})</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
