import React from 'react';
import { Sparkles, ShieldCheck, QrCode, Truck, ArrowRight } from 'lucide-react';
import { STORE_CONFIG } from '../data/mockData';

interface HeroBannerProps {
  onExplore: () => void;
  onSelectCategory: (category: any) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ onExplore, onSelectCategory }) => {
  return (
    <section className="relative overflow-hidden bg-luxury-pattern border-b border-[#E8E4DC] transition-all">
      {/* Subtle Ambient Decorative Glows */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#C9A96E]/10 rounded-full blur-3xl pointer-events-none -z-0" />
      <div className="absolute bottom-0 left-10 w-80 h-80 bg-[#8C6D37]/8 rounded-full blur-3xl pointer-events-none -z-0" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
          {/* Left Editorial Copy */}
          <div className="lg:col-span-7 space-y-7">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/90 shadow-sm border border-[#DFCDB7] text-xs font-bold text-[#8C6D37] tracking-widest uppercase backdrop-blur-sm">
              <Sparkles className="w-4 h-4 text-[#C9A96E]" />
              <span>LUXURY BOUTIQUE • ĐÀ NẴNG</span>
            </div>

            <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-[#111111] leading-[1.2]">
              Thời trang chuẩn mực <span className="font-display tracking-wider text-[#8C6D37]">LUXURY</span>, <br />
              <span className="italic font-serif font-normal text-neutral-800">tôn vinh phong cách & form dáng</span> hoàn hảo.
            </h1>

            <p className="text-neutral-600 text-base sm:text-lg leading-relaxed max-w-2xl font-normal">
              Bộ sưu tập áo thun cotton 100% định lượng cao, sơ mi lụa mềm mại, quần jean form suông và blazer cao cấp. Từng đường kim mũi chỉ được hoàn thiện tỉ mỉ, thanh toán tiện lợi cùng VietQR MBBank.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                id="btn-hero-explore"
                type="button"
                onClick={onExplore}
                className="px-8 py-4 rounded-full bg-[#111111] text-white font-semibold text-sm tracking-wider hover:bg-[#2A2A2A] transition-all flex items-center gap-2 shadow-lg hover:shadow-xl active:scale-95"
              >
                <span>Khám phá bộ sưu tập</span>
                <ArrowRight className="w-4 h-4 text-[#C9A96E]" />
              </button>

              <button
                id="btn-hero-tshirt"
                type="button"
                onClick={() => onSelectCategory('t-shirt')}
                className="px-6 py-4 rounded-full bg-white text-neutral-900 border border-neutral-300 font-semibold text-sm hover:border-[#111111] hover:bg-neutral-50 transition-all shadow-sm"
              >
                Áo Thun & Polo
              </button>

              <button
                id="btn-hero-jeans"
                type="button"
                onClick={() => onSelectCategory('jeans')}
                className="px-6 py-4 rounded-full bg-white text-neutral-900 border border-neutral-300 font-semibold text-sm hover:border-[#111111] hover:bg-neutral-50 transition-all shadow-sm"
              >
                Quần Jean & Tây
              </button>
            </div>

            {/* Value Props Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-8 border-t border-neutral-300/80 text-xs text-neutral-700">
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/80 backdrop-blur-sm border border-neutral-200/80 shadow-sm">
                <div className="p-2.5 rounded-xl bg-[#FAF8F5] border border-[#E7DAC7] text-[#8C6D37]">
                  <QrCode className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-neutral-900">MBBank VietQR</p>
                  <p className="text-[11px] text-neutral-500">Quét mã nhận hàng 24/7</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/80 backdrop-blur-sm border border-neutral-200/80 shadow-sm">
                <div className="p-2.5 rounded-xl bg-[#FAF8F5] border border-[#E7DAC7] text-[#8C6D37]">
                  <Truck className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-neutral-900">Giao Hỏa Tốc ĐN</p>
                  <p className="text-[11px] text-neutral-500">Freeship từ 499k</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/80 backdrop-blur-sm border border-neutral-200/80 shadow-sm col-span-2 sm:col-span-1">
                <div className="p-2.5 rounded-xl bg-[#FAF8F5] border border-[#E7DAC7] text-[#8C6D37]">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-neutral-900">Chất Lượng Cao Cấp</p>
                  <p className="text-[11px] text-neutral-500">Đổi size trong 7 ngày</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Visual Composition */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Main Fashion Hero Image */}
              <div className="relative rounded-3xl overflow-hidden aspect-[4/5] shadow-2xl border-4 border-white">
                <img
                  src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=85"
                  alt="Thời trang cao cấp LUXURY"
                  className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700"
                />
                
                {/* Overlay Badge */}
                <div className="absolute bottom-5 left-5 right-5 bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-neutral-200 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-extrabold tracking-widest text-[#8C6D37] uppercase block">
                      SHOWROOM ĐÀ NẴNG
                    </span>
                    <p className="text-sm font-bold text-neutral-900">
                      LUXURY BOUTIQUE
                    </p>
                    <p className="text-xs text-neutral-500 font-medium">
                      Hotline: {STORE_CONFIG.phone}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-neutral-400 block">Địa chỉ</span>
                    <span className="text-xs font-bold text-neutral-800">
                      {STORE_CONFIG.address}, Đà Nẵng
                    </span>
                  </div>
                </div>
              </div>

              {/* Floating Highlight Card */}
              <div className="absolute -top-4 -left-4 bg-[#111111] text-white px-5 py-3 rounded-2xl shadow-2xl hidden sm:flex items-center gap-3 border border-[#C9A96E]/50">
                <div className="w-2.5 h-2.5 rounded-full bg-[#C9A96E] animate-ping" />
                <div className="text-xs">
                  <span className="font-bold text-[#E7DAC7] tracking-wider block">LUXURY COLLECTION 2026</span>
                  <p className="text-[10px] text-neutral-300">Hàng mới có sẵn tại cửa hàng</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
