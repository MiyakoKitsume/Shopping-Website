export type Category = 
  | 'all'
  | 't-shirt'
  | 'shirt'
  | 'jeans'
  | 'trousers'
  | 'dress'
  | 'jacket'
  | 'polo';

export type Gender = 'all' | 'men' | 'women' | 'unisex';

export type Size = 'S' | 'M' | 'L' | 'XL' | 'XXL';

export interface Product {
  id: string;
  name: string;
  category: Category;
  categoryName: string;
  gender: Gender;
  price: number;
  originalPrice?: number;
  images: string[];
  sizes: Size[];
  colors: { name: string; hex: string }[];
  stock: number;
  description: string;
  material: string;
  careGuide: string;
  isNew?: boolean;
  isBestSeller?: boolean;
  rating: number;
  reviewCount: number;
  sku: string;
}

export interface CartItem {
  product: Product;
  selectedSize: Size;
  selectedColor: { name: string; hex: string };
  quantity: number;
}

export type PaymentMethod = 'mbbank_qr' | 'mbbank_transfer' | 'cod';

export type PaymentStatus = 'pending' | 'paid' | 'verified';

export type ShippingStatus = 'processing' | 'confirmed' | 'shipping' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  orderCode: string;
  createdAt: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  customerAddress: string;
  city: string;
  district: string;
  note?: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  totalAmount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  shippingStatus: ShippingStatus;
  transferProofImage?: string;
  bankTransactionCode?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  provider: 'google' | 'facebook' | 'email' | 'guest';
  role: 'admin' | 'customer';
  loyaltyPoints: number;
  savedAddresses?: string[];
  createdAt: string;
}

export interface FilterState {
  category: Category;
  gender: Gender;
  minPrice: number;
  maxPrice: number;
  sizes: Size[];
  colors: string[];
  searchQuery: string;
  sortBy: 'featured' | 'newest' | 'price-asc' | 'price-desc' | 'best-selling';
  onlyDiscount: boolean;
  onlyInStock: boolean;
}

export interface StoreConfig {
  storeName: string;
  ownerName: string;
  managerName: string;
  phone: string;
  zalo: string;
  facebookName: string;
  facebookUrl: string;
  address: string;
  ward: string;
  city: string;
  bankName: string;
  bankCode: string;
  bankAccountNumber: string;
  bankAccountName: string;
  openingHours: string;
}
