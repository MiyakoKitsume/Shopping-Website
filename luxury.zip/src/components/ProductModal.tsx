import React, { useState } from 'react';
import { 
  X, 
  Star, 
  ShoppingBag, 
  QrCode, 
  Check, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Info,
  Heart,
  Share2
} from 'lucide-react';
import { Product, Size } from '../types';
import { formatVND, getVietQRUrl } from '../lib/utils';
import { STORE_CONFIG } from '../data/mockData';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, size: Size, color: { name: string; hex: string }, quantity: number) => void;
  onBuyNow: (product: Product, size: Size, color: { name: string; hex: string }, quantity: number) => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onBuyNow,
  isWishlisted,
  onToggleWishlist,
}) => {
  if (!product) return null;

  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<Size>(product.sizes[0] || 'M');
  const [selectedColor, setSelectedColor] = useState(product.colors[0] || { name: 'Mặc định', hex: '#000000' });
  const [quantity, setQuantity] = useState(1);
  const [addedToast, setAddedToast] = useState(false);

  const handleAdd = () => {
    onAddToCart(product, selectedSize, selectedColor, quantity);
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2000);
  };

  const handleDirectBuy = () => {
    onBuyNow(product, selectedSize, selectedColor, quantity);
  };

  const discountPercent = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 md:p-6 animate-fadeIn">
      <div 
        className="relative bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-neutral-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          id="btn-close-product-modal"
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/90 hover:bg-neutral-100 text-neutral-600 hover:text-neutral-950 shadow-md transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 p-6 sm:p-8">
          {/* Left Column: Gallery */}
          <div className="md:col-span-6 space-y-4">
            {/* Main Image */}
            <div className="relative aspect-[3/4] w-full rounded-2xl overflow-hidden bg-neutral-100 border border-neutral-200">
              <img
                src={product.images[selectedImageIndex] || product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover object-center"
              />
              {discountPercent > 0 && (
                <div className="absolute top-3 left-3 bg-rose-600 text-white font-bold text-xs px-2.5 py-1 rounded-full shadow">
                  Giảm {discountPercent}%
                </div>
              )}
            </div>

            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex items-center gap-3 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedImageIndex(idx)}
                    className={`relative w-16 h-20 rounded-lg overflow-hidden border-2 flex-shrink-0 transition-all ${
                      selectedImageIndex === idx
                        ? 'border-[#8C6D37] ring-2 ring-[#C9A96E]/40'
                        : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt={`thumbnail-${idx}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Information & Actions */}
          <div className="md:col-span-6 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              {/* Category & SKU */}
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-[#8C6D37] uppercase tracking-wider">
                  {product.categoryName} • Mã SP: {product.sku}
                </span>
                <button
                  type="button"
                  onClick={() => onToggleWishlist(product)}
                  className="flex items-center gap-1 text-neutral-500 hover:text-rose-600 transition-colors"
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
                  <span className="text-xs">{isWishlisted ? 'Đã thích' : 'Yêu thích'}</span>
                </button>
              </div>

              {/* Product Title */}
              <h2 className="font-serif text-2xl font-bold text-neutral-900 leading-tight">
                {product.name}
              </h2>

              {/* Rating & Reviews */}
              <div className="flex items-center gap-3 text-xs text-neutral-600">
                <div className="flex items-center gap-1 text-amber-500">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="font-bold text-neutral-900">{product.rating}</span>
                </div>
                <span>•</span>
                <span>{product.reviewCount} đánh giá đã mua</span>
                <span>•</span>
                <span className="text-emerald-700 font-medium">Kho: {product.stock} chiếc</span>
              </div>

              {/* Price */}
              <div className="flex items-baseline gap-3 p-3.5 rounded-xl bg-[#FAF8F5] border border-[#EAE6DF]">
                <span className="text-2xl sm:text-3xl font-bold text-neutral-900">
                  {formatVND(product.price)}
                </span>
                {product.originalPrice && (
                  <span className="text-sm text-neutral-400 line-through">
                    {formatVND(product.originalPrice)}
                  </span>
                )}
                <span className="text-xs text-[#8C6D37] font-semibold ml-auto">
                  Thanh toán MBBank QR
                </span>
              </div>

              {/* Color Selector */}
              <div>
                <label className="text-xs font-bold text-neutral-800 uppercase tracking-wider block mb-2">
                  Màu Sắc: <span className="font-normal text-neutral-600">{selectedColor.name}</span>
                </label>
                <div className="flex items-center gap-2.5 flex-wrap">
                  {product.colors.map((color, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedColor(color)}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all ${
                        selectedColor.name === color.name
                          ? 'border-[#1A1A1A] bg-neutral-900 text-white shadow-sm'
                          : 'border-neutral-200 bg-white text-neutral-700 hover:border-neutral-400'
                      }`}
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-white/40"
                        style={{ backgroundColor: color.hex }}
                      />
                      <span>{color.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selector */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-bold text-neutral-800 uppercase tracking-wider">
                    Chọn Size
                  </label>
                  <span className="text-[11px] text-neutral-500 underline cursor-pointer">
                    Bảng tư vấn size chuẩn Việt Nam
                  </span>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setSelectedSize(size)}
                      className={`py-2.5 rounded-xl text-xs font-bold transition-all ${
                        selectedSize === size
                          ? 'bg-[#1A1A1A] text-white shadow-sm ring-2 ring-[#C9A96E]/50'
                          : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-800'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity */}
              <div>
                <label className="text-xs font-bold text-neutral-800 uppercase tracking-wider block mb-2">
                  Số Lượng
                </label>
                <div className="flex items-center gap-3">
                  <div className="flex items-center border border-neutral-300 rounded-xl overflow-hidden bg-white">
                    <button
                      type="button"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-2 text-neutral-600 hover:bg-neutral-100 font-bold"
                    >
                      -
                    </button>
                    <span className="px-4 py-2 text-xs font-bold text-neutral-900">
                      {quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                      className="px-3 py-2 text-neutral-600 hover:bg-neutral-100 font-bold"
                    >
                      +
                    </button>
                  </div>
                  <span className="text-xs text-neutral-500">
                    Tạm tính: <strong className="text-neutral-900">{formatVND(product.price * quantity)}</strong>
                  </span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 pt-4 border-t border-neutral-100">
              {addedToast && (
                <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-2 rounded-xl text-xs font-medium flex items-center gap-2 animate-bounce">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Đã thêm sản phẩm vào giỏ hàng thành công!</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  id="btn-modal-add-cart"
                  type="button"
                  onClick={handleAdd}
                  className="w-full py-3.5 px-4 rounded-xl bg-white border-2 border-[#1A1A1A] text-neutral-900 font-semibold text-xs tracking-wider uppercase hover:bg-neutral-50 transition-colors flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Thêm Vào Giỏ</span>
                </button>

                <button
                  id="btn-modal-buy-now"
                  type="button"
                  onClick={handleDirectBuy}
                  className="w-full py-3.5 px-4 rounded-xl bg-[#1A1A1A] text-white font-semibold text-xs tracking-wider uppercase hover:bg-[#333] transition-colors flex items-center justify-center gap-2 shadow-lg"
                >
                  <QrCode className="w-4 h-4 text-[#C9A96E]" />
                  <span>Mua Ngay (MBBank QR)</span>
                </button>
              </div>

              {/* Guarantees */}
              <div className="grid grid-cols-3 gap-2 pt-3 text-[11px] text-neutral-500">
                <div className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-[#8C6D37]" />
                  <span>Ship nhanh Đà Nẵng</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <RotateCcw className="w-3.5 h-3.5 text-[#8C6D37]" />
                  <span>Đổi trả 7 ngày</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#8C6D37]" />
                  <span>Chính hãng 100%</span>
                </div>
              </div>
            </div>

            {/* Description & Specs Accordion */}
            <div className="border-t border-neutral-100 pt-4 text-xs space-y-2 text-neutral-600">
              <p className="font-semibold text-neutral-900">Chi tiết sản phẩm:</p>
              <p className="leading-relaxed">{product.description}</p>
              <div className="grid grid-cols-2 gap-2 pt-2 text-[11px] bg-neutral-50 p-3 rounded-xl">
                <div>
                  <span className="font-bold text-neutral-800">Chất liệu:</span> {product.material}
                </div>
                <div>
                  <span className="font-bold text-neutral-800">Bảo quản:</span> {product.careGuide}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
