import React from 'react';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { Product } from '../types';
import { formatVND } from '../lib/utils';

interface WishlistModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: Product[];
  onRemoveWishlist: (product: Product) => void;
  onQuickAddToCart: (product: Product) => void;
}

export const WishlistModal: React.FC<WishlistModalProps> = ({
  isOpen,
  onClose,
  items,
  onRemoveWishlist,
  onQuickAddToCart,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div 
        className="relative bg-white rounded-3xl max-w-lg w-full max-h-[85vh] flex flex-col shadow-2xl border border-neutral-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-rose-600 fill-current" />
            <h3 className="font-serif text-lg font-bold text-neutral-900">
              Sản Phẩm Yêu Thích ({items.length})
            </h3>
          </div>
          <button
            id="btn-close-wishlist"
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-neutral-500 hover:bg-neutral-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wishlist Items List */}
        <div className="p-5 overflow-y-auto flex-1 divide-y divide-neutral-100 space-y-3">
          {items.length === 0 ? (
            <div className="text-center py-12 text-neutral-500 space-y-2">
              <Heart className="w-10 h-10 mx-auto text-neutral-300 stroke-1" />
              <p className="text-sm font-semibold text-neutral-800">Chưa có sản phẩm yêu thích nào</p>
              <p className="text-xs">Bấm vào biểu tượng trái tim để lưu lại mẫu bạn yêu thích.</p>
            </div>
          ) : (
            items.map((item) => (
              <div key={item.id} className="pt-3 first:pt-0 flex items-center gap-3">
                <img
                  src={item.images[0]}
                  alt={item.name}
                  className="w-16 h-20 rounded-xl object-cover border"
                />
                <div className="flex-1">
                  <h4 className="font-medium text-xs text-neutral-900 line-clamp-1">{item.name}</h4>
                  <p className="text-xs font-bold text-neutral-900 mt-1 font-sans">{formatVND(item.price)}</p>
                  <span className="text-[10px] text-emerald-700">Còn hàng trong kho</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      onQuickAddToCart(item);
                      onRemoveWishlist(item);
                    }}
                    className="p-2 bg-[#1A1A1A] hover:bg-[#333] text-white rounded-xl transition-colors"
                    title="Thêm vào giỏ hàng"
                  >
                    <ShoppingBag className="w-4 h-4 text-[#C9A96E]" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onRemoveWishlist(item)}
                    className="p-2 text-neutral-400 hover:text-rose-600 rounded-xl hover:bg-neutral-100 transition-colors"
                    title="Xóa"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
