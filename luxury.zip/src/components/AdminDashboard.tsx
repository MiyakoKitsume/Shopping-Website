import React, { useState } from 'react';
import { 
  TrendingUp, 
  ShoppingBag, 
  Package, 
  Users, 
  Plus, 
  Edit3, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  Truck, 
  QrCode, 
  Search, 
  SlidersHorizontal,
  Building, 
  Phone, 
  MapPin, 
  Sparkles,
  DollarSign,
  AlertCircle,
  Eye
} from 'lucide-react';
import { Product, Order, StoreConfig, User, Size, Category } from '../types';
import { formatVND, getVietQRUrl } from '../lib/utils';

interface AdminDashboardProps {
  products: Product[];
  orders: Order[];
  storeConfig: StoreConfig;
  onUpdateProduct: (product: Product) => void;
  onAddProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  onUpdateOrderStatus: (orderId: string, paymentStatus: any, shippingStatus: any) => void;
  onUpdateConfig: (config: StoreConfig) => void;
  onBackToStore: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  products,
  orders,
  storeConfig,
  onUpdateProduct,
  onAddProduct,
  onDeleteProduct,
  onUpdateOrderStatus,
  onUpdateConfig,
  onBackToStore,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'products' | 'settings'>('overview');
  
  // Product management state
  const [searchProduct, setSearchProduct] = useState('');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);

  // New product form
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState<Category>('t-shirt');
  const [newProdPrice, setNewProdPrice] = useState(250000);
  const [newProdOriginalPrice, setNewProdOriginalPrice] = useState(320000);
  const [newProdStock, setNewProdStock] = useState(50);
  const [newProdMaterial, setNewProdMaterial] = useState('100% Cotton thoáng mát');
  const [newProdDesc, setNewProdDesc] = useState('');
  const [newProdImg, setNewProdImg] = useState('https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80');

  // Orders filtering
  const [orderStatusFilter, setOrderStatusFilter] = useState<'all' | 'pending' | 'paid' | 'shipping' | 'delivered'>('all');
  const [searchOrder, setSearchOrder] = useState('');
  const [selectedProofOrder, setSelectedProofOrder] = useState<Order | null>(null);

  // Financial metrics
  const totalRevenue = orders.reduce((sum, ord) => (ord.paymentStatus !== 'pending' ? sum + ord.totalAmount : sum), 0);
  const pendingOrders = orders.filter((ord) => ord.paymentStatus === 'pending');
  const totalStockCount = products.reduce((sum, p) => sum + p.stock, 0);
  const lowStockProducts = products.filter((p) => p.stock <= 25);

  const filteredOrders = orders.filter((ord) => {
    const matchesSearch = 
      ord.orderCode.toLowerCase().includes(searchOrder.toLowerCase()) ||
      ord.customerName.toLowerCase().includes(searchOrder.toLowerCase()) ||
      ord.customerPhone.includes(searchOrder);
    
    if (!matchesSearch) return false;
    if (orderStatusFilter === 'all') return true;
    if (orderStatusFilter === 'pending') return ord.paymentStatus === 'pending';
    if (orderStatusFilter === 'paid') return ord.paymentStatus === 'paid';
    if (orderStatusFilter === 'shipping') return ord.shippingStatus === 'shipping';
    if (orderStatusFilter === 'delivered') return ord.shippingStatus === 'delivered';
    return true;
  });

  const filteredProducts = products.filter((p) =>
    p.name.toLowerCase().includes(searchProduct.toLowerCase()) ||
    p.sku.toLowerCase().includes(searchProduct.toLowerCase())
  );

  const handleSaveNewProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const product: Product = {
      id: `prod-${Date.now()}`,
      sku: `NT-${newProdCategory.slice(0, 3).toUpperCase()}-${Math.floor(10 + Math.random() * 90)}`,
      name: newProdName,
      category: newProdCategory,
      categoryName: newProdCategory === 't-shirt' ? 'Áo Thun' : newProdCategory === 'shirt' ? 'Áo Sơ Mi' : newProdCategory === 'jeans' ? 'Quần Jean' : 'Thời Trang',
      gender: 'unisex',
      price: Number(newProdPrice),
      originalPrice: Number(newProdOriginalPrice),
      images: [newProdImg],
      sizes: ['S', 'M', 'L', 'XL'],
      colors: [
        { name: 'Đen', hex: '#1A1A1A' },
        { name: 'Trắng', hex: '#FFFFFF' }
      ],
      stock: Number(newProdStock),
      description: newProdDesc || 'Sản phẩm thời trang cao cấp phong cách đương đại.',
      material: newProdMaterial,
      careGuide: 'Giặt máy nhẹ nhàng, phơi bóng mát.',
      rating: 5.0,
      reviewCount: 1,
      isNew: true
    };

    onAddProduct(product);
    setIsAddingProduct(false);
    // reset
    setNewProdName('');
    setNewProdDesc('');
  };

  return (
    <div className="bg-[#FAF8F5] min-h-screen pb-16">
      {/* Top Admin Header Bar */}
      <div className="bg-[#1A1A1A] text-white border-b border-[#333]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-[#C9A96E] text-[#1A1A1A] text-[10px] font-bold px-2 py-0.5 rounded tracking-wider uppercase">
                  Bảng Điều Khiển Quản Lý
                </span>
                <span className="text-xs text-neutral-400 font-mono">Phiên bản 2026.1</span>
              </div>
              <h1 className="font-serif text-2xl font-bold text-white mt-1">
                Hệ Thống Quản Trị {storeConfig.storeName}
              </h1>
              <p className="text-xs text-neutral-400">
                Showroom: {storeConfig.address}, {storeConfig.city} • Hotline: {storeConfig.phone}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onBackToStore}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-2"
              >
                <ShoppingBag className="w-4 h-4 text-[#C9A96E]" />
                <span>Xem Trang Mua Sắm</span>
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 mt-6 overflow-x-auto pb-1 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'overview'
                  ? 'bg-[#C9A96E] text-[#1A1A1A] font-bold shadow'
                  : 'bg-white/5 text-neutral-300 hover:bg-white/10'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>Tổng Quan & Doanh Thu</span>
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'orders'
                  ? 'bg-[#C9A96E] text-[#1A1A1A] font-bold shadow'
                  : 'bg-white/5 text-neutral-300 hover:bg-white/10'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>Quản Lý Đơn Hàng ({orders.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('products')}
              className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'products'
                  ? 'bg-[#C9A96E] text-[#1A1A1A] font-bold shadow'
                  : 'bg-white/5 text-neutral-300 hover:bg-white/10'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Kho & Sản Phẩm ({products.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
                activeTab === 'settings'
                  ? 'bg-[#C9A96E] text-[#1A1A1A] font-bold shadow'
                  : 'bg-white/5 text-neutral-300 hover:bg-white/10'
              }`}
            >
              <Building className="w-4 h-4" />
              <span>Thông Tin Shop & MBBank</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {/* 1. OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* KPI Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-sm space-y-2">
                <div className="flex items-center justify-between text-neutral-500 text-xs font-bold uppercase">
                  <span>Doanh Thu MBBank</span>
                  <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
                    <DollarSign className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-neutral-900 font-sans">
                  {formatVND(totalRevenue)}
                </div>
                <div className="text-[11px] text-emerald-700 flex items-center gap-1 font-medium">
                  <span>✓ Cập nhật tự động qua VietQR</span>
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-sm space-y-2">
                <div className="flex items-center justify-between text-neutral-500 text-xs font-bold uppercase">
                  <span>Tổng Số Đơn Hàng</span>
                  <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
                    <Package className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-neutral-900">
                  {orders.length} đơn
                </div>
                <div className="text-[11px] text-neutral-500">
                  {pendingOrders.length} đơn đang chờ xác nhận
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-sm space-y-2">
                <div className="flex items-center justify-between text-neutral-500 text-xs font-bold uppercase">
                  <span>Tồn Kho Quần Áo</span>
                  <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
                    <ShoppingBag className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-neutral-900">
                  {totalStockCount} sản phẩm
                </div>
                <div className="text-[11px] text-amber-700 font-medium">
                  {lowStockProducts.length} mẫu sắp hết hàng (&lt;25 cái)
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-sm space-y-2">
                <div className="flex items-center justify-between text-neutral-500 text-xs font-bold uppercase">
                  <span>Tài Khoản MBBank</span>
                  <div className="p-2 rounded-xl bg-neutral-100 text-neutral-800">
                    <QrCode className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-base font-bold text-neutral-900 font-mono">
                  {storeConfig.bankAccountNumber}
                </div>
                <div className="text-[11px] text-[#8C6D37] font-semibold">
                  Chủ TK: {storeConfig.bankAccountName}
                </div>
              </div>
            </div>

            {/* Quick Actions & Recent Orders Table */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Column: Recent Orders (8 cols) */}
              <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                  <h3 className="font-bold text-base text-neutral-900 flex items-center gap-2">
                    <Package className="w-4 h-4 text-[#8C6D37]" />
                    <span>Đơn Hàng Gần Đây</span>
                  </h3>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-xs text-[#8C6D37] font-bold hover:underline"
                  >
                    Xem tất cả ({orders.length}) →
                  </button>
                </div>

                <div className="divide-y divide-neutral-100 overflow-x-auto">
                  {orders.slice(0, 4).map((ord) => (
                    <div key={ord.id} className="py-3 flex items-center justify-between gap-4 text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-neutral-900">{ord.orderCode}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            ord.paymentStatus === 'paid' || ord.paymentStatus === 'verified'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}>
                            {ord.paymentStatus === 'paid' ? 'Đã thanh toán MB' : 'Chờ thanh toán'}
                          </span>
                        </div>
                        <p className="text-neutral-500 mt-0.5">
                          {ord.customerName} • {ord.customerPhone} • {ord.createdAt}
                        </p>
                      </div>

                      <div className="text-right">
                        <span className="font-bold text-neutral-900 text-sm">{formatVND(ord.totalAmount)}</span>
                        <p className="text-[11px] text-neutral-500 capitalize">{ord.shippingStatus}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Column: Store Management Quick Profile (4 cols) */}
              <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-5">
                <h3 className="font-bold text-base text-neutral-900 flex items-center gap-2 border-b border-neutral-100 pb-3">
                  <Building className="w-4 h-4 text-[#8C6D37]" />
                  <span>Đại Diện Shop Đà Nẵng</span>
                </h3>

                <div className="space-y-3 text-xs text-neutral-700">
                  <div className="p-3 bg-[#FAF8F5] rounded-xl border border-[#EAE6DF] space-y-1">
                    <span className="text-[10px] font-bold text-[#8C6D37] uppercase">Chủ Cửa Hàng</span>
                    <p className="font-bold text-sm text-neutral-900">{storeConfig.ownerName}</p>
                    <p className="text-neutral-500">Facebook: {storeConfig.facebookName}</p>
                  </div>

                  <div className="p-3 bg-[#FAF8F5] rounded-xl border border-[#EAE6DF] space-y-1">
                    <span className="text-[10px] font-bold text-[#8C6D37] uppercase">Quản Lý Cửa Hàng</span>
                    <p className="font-bold text-sm text-neutral-900">{storeConfig.managerName}</p>
                    <p className="text-neutral-500">Phụ trách: Kiểm hàng, tư vấn & vận hành</p>
                  </div>

                  <div className="space-y-1.5 pt-2">
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-[#8C6D37]" />
                      <span>Hotline/Zalo: <strong>{storeConfig.phone}</strong></span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-[#8C6D37]" />
                      <span>{storeConfig.address}, {storeConfig.ward}, {storeConfig.city}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 2. ORDERS MANAGEMENT TAB */}
        {activeTab === 'orders' && (
          <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h2 className="font-serif text-xl font-bold text-neutral-900">
                  Quản Lý Đơn Hàng & MBBank VietQR
                </h2>
                <p className="text-xs text-neutral-500">
                  Kiểm tra thanh toán, xác nhận biên lai và điều phối vận chuyển
                </p>
              </div>

              {/* Search Orders */}
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchOrder}
                  onChange={(e) => setSearchOrder(e.target.value)}
                  placeholder="Tìm mã đơn, tên, SĐT..."
                  className="w-full pl-9 pr-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:border-[#8C6D37]"
                />
              </div>
            </div>

            {/* Filter status tabs */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              {[
                { id: 'all', label: 'Tất cả đơn' },
                { id: 'pending', label: 'Chờ thanh toán' },
                { id: 'paid', label: 'Đã thanh toán MB' },
                { id: 'shipping', label: 'Đang giao hàng' },
                { id: 'delivered', label: 'Đã hoàn thành' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setOrderStatusFilter(f.id as any)}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                    orderStatusFilter === f.id
                      ? 'bg-[#1A1A1A] text-white shadow-sm'
                      : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* Orders Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-neutral-700">
                <thead className="bg-[#FAF8F5] border-y border-neutral-200 text-neutral-600 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="py-3 px-3">Mã Đơn / Ngày</th>
                    <th className="py-3 px-3">Khách Hàng</th>
                    <th className="py-3 px-3">Sản Phẩm Đặt</th>
                    <th className="py-3 px-3">Tổng Tiền</th>
                    <th className="py-3 px-3">Thanh Toán MB</th>
                    <th className="py-3 px-3">Vận Chuyển</th>
                    <th className="py-3 px-3 text-right">Thao Tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {filteredOrders.map((ord) => (
                    <tr key={ord.id} className="hover:bg-neutral-50/80 transition-colors">
                      <td className="py-3 px-3">
                        <span className="font-mono font-bold text-neutral-900 block">{ord.orderCode}</span>
                        <span className="text-[10px] text-neutral-400">{ord.createdAt}</span>
                      </td>

                      <td className="py-3 px-3">
                        <span className="font-semibold text-neutral-900 block">{ord.customerName}</span>
                        <span className="text-[11px] text-neutral-500">{ord.customerPhone}</span>
                        <span className="text-[10px] text-neutral-400 block truncate max-w-[140px]">
                          {ord.customerAddress}
                        </span>
                      </td>

                      <td className="py-3 px-3">
                        <div className="space-y-0.5">
                          {ord.items.map((it, idx) => (
                            <span key={idx} className="block text-[11px] text-neutral-700">
                              • {it.quantity}x {it.product.name} (Size {it.selectedSize})
                            </span>
                          ))}
                        </div>
                      </td>

                      <td className="py-3 px-3 font-bold text-neutral-900 text-sm font-sans">
                        {formatVND(ord.totalAmount)}
                      </td>

                      <td className="py-3 px-3">
                        <select
                          value={ord.paymentStatus}
                          onChange={(e) => onUpdateOrderStatus(ord.id, e.target.value as any, ord.shippingStatus)}
                          className={`text-[11px] font-bold px-2 py-1 rounded-lg border outline-none ${
                            ord.paymentStatus === 'paid' || ord.paymentStatus === 'verified'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                              : 'bg-amber-50 text-amber-800 border-amber-300'
                          }`}
                        >
                          <option value="pending">⏳ Chờ thanh toán</option>
                          <option value="paid">✓ Đã chuyển khoản MB</option>
                          <option value="verified">⭐ Đã xác thực tiền về</option>
                        </select>

                        {ord.transferProofImage && (
                          <button
                            type="button"
                            onClick={() => setSelectedProofOrder(ord)}
                            className="mt-1 flex items-center gap-1 text-[10px] text-blue-600 font-bold hover:underline"
                          >
                            <Eye className="w-3 h-3" />
                            <span>Xem biên lai</span>
                          </button>
                        )}
                      </td>

                      <td className="py-3 px-3">
                        <select
                          value={ord.shippingStatus}
                          onChange={(e) => onUpdateOrderStatus(ord.id, ord.paymentStatus, e.target.value as any)}
                          className="text-[11px] font-medium px-2 py-1 rounded-lg border border-neutral-300 bg-white"
                        >
                          <option value="processing">Đang đóng gói</option>
                          <option value="confirmed">Đã duyệt đơn</option>
                          <option value="shipping">Đang giao nội thành</option>
                          <option value="delivered">Đã giao thành công</option>
                          <option value="cancelled">Hủy đơn</option>
                        </select>
                      </td>

                      <td className="py-3 px-3 text-right">
                        <button
                          type="button"
                          onClick={() => window.print()}
                          className="px-2.5 py-1 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded font-semibold text-[11px]"
                        >
                          In đơn
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Proof Modal View */}
            {selectedProofOrder && selectedProofOrder.transferProofImage && (
              <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl max-w-sm w-full p-5 space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="font-bold text-sm text-neutral-900">
                      Biên lai chuyển khoản: {selectedProofOrder.orderCode}
                    </h4>
                    <button onClick={() => setSelectedProofOrder(null)} className="p-1 text-neutral-500">
                      ✕
                    </button>
                  </div>
                  <img
                    src={selectedProofOrder.transferProofImage}
                    alt="Biên lai"
                    className="w-full rounded-xl border object-contain max-h-80 mx-auto"
                  />
                  <div className="text-xs text-neutral-600">
                    <p>Khách hàng: <strong>{selectedProofOrder.customerName}</strong></p>
                    <p>Số tiền: <strong>{formatVND(selectedProofOrder.totalAmount)}</strong></p>
                  </div>
                  <button
                    onClick={() => {
                      onUpdateOrderStatus(selectedProofOrder.id, 'verified', selectedProofOrder.shippingStatus);
                      setSelectedProofOrder(null);
                    }}
                    className="w-full py-2 bg-emerald-600 text-white rounded-xl font-bold text-xs hover:bg-emerald-700"
                  >
                    Xác Nhận Tiền Đã Vào MBBank
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 3. PRODUCTS & INVENTORY TAB */}
        {activeTab === 'products' && (
          <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h2 className="font-serif text-xl font-bold text-neutral-900">
                  Quản Lý Danh Mục & Kho Hàng Quần Áo
                </h2>
                <p className="text-xs text-neutral-500">
                  Thêm mới, sửa giá, điều chỉnh số lượng tồn kho theo chuẩn cửa hàng
                </p>
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-60">
                  <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={searchProduct}
                    onChange={(e) => setSearchProduct(e.target.value)}
                    placeholder="Tìm tên hoặc SKU..."
                    className="w-full pl-9 pr-3 py-2 text-xs bg-neutral-50 border border-neutral-200 rounded-xl outline-none focus:border-[#8C6D37]"
                  />
                </div>

                <button
                  id="btn-admin-add-product"
                  type="button"
                  onClick={() => setIsAddingProduct(true)}
                  className="px-4 py-2 bg-[#1A1A1A] hover:bg-[#333] text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shadow"
                >
                  <Plus className="w-4 h-4 text-[#C9A96E]" />
                  <span>Thêm Sản Phẩm Mới</span>
                </button>
              </div>
            </div>

            {/* Add Product Form Modal */}
            {isAddingProduct && (
              <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
                  <div className="flex justify-between items-center border-b pb-3">
                    <h3 className="font-bold text-base text-neutral-900">
                      Thêm Mẫu Quần Áo Mới Vào Kho
                    </h3>
                    <button onClick={() => setIsAddingProduct(false)} className="text-neutral-400 hover:text-neutral-700">
                      ✕
                    </button>
                  </div>

                  <form onSubmit={handleSaveNewProduct} className="space-y-3.5 text-xs">
                    <div>
                      <label className="font-semibold text-neutral-700 block mb-1">Tên sản phẩm *</label>
                      <input
                        type="text"
                        required
                        value={newProdName}
                        onChange={(e) => setNewProdName(e.target.value)}
                        placeholder="VD: Áo Thun Oversize Cotton 250gsm"
                        className="w-full px-3 py-2 border rounded-xl"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="font-semibold text-neutral-700 block mb-1">Danh mục</label>
                        <select
                          value={newProdCategory}
                          onChange={(e) => setNewProdCategory(e.target.value as any)}
                          className="w-full px-3 py-2 border rounded-xl bg-white"
                        >
                          <option value="t-shirt">Áo Thun</option>
                          <option value="shirt">Áo Sơ Mi</option>
                          <option value="jeans">Quần Jean</option>
                          <option value="trousers">Quần Tây</option>
                          <option value="dress">Váy Đầm</option>
                          <option value="polo">Áo Polo</option>
                          <option value="jacket">Áo Khoác</option>
                        </select>
                      </div>

                      <div>
                        <label className="font-semibold text-neutral-700 block mb-1">Số lượng nhập kho</label>
                        <input
                          type="number"
                          required
                          value={newProdStock}
                          onChange={(e) => setNewProdStock(Number(e.target.value))}
                          className="w-full px-3 py-2 border rounded-xl"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="font-semibold text-neutral-700 block mb-1">Giá bán (VNĐ) *</label>
                        <input
                          type="number"
                          required
                          step="10000"
                          value={newProdPrice}
                          onChange={(e) => setNewProdPrice(Number(e.target.value))}
                          className="w-full px-3 py-2 border rounded-xl"
                        />
                      </div>

                      <div>
                        <label className="font-semibold text-neutral-700 block mb-1">Giá gốc niêm yết (VNĐ)</label>
                        <input
                          type="number"
                          step="10000"
                          value={newProdOriginalPrice}
                          onChange={(e) => setNewProdOriginalPrice(Number(e.target.value))}
                          className="w-full px-3 py-2 border rounded-xl"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="font-semibold text-neutral-700 block mb-1">URL Hình Ảnh</label>
                      <input
                        type="url"
                        value={newProdImg}
                        onChange={(e) => setNewProdImg(e.target.value)}
                        className="w-full px-3 py-2 border rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="font-semibold text-neutral-700 block mb-1">Chất liệu vải</label>
                      <input
                        type="text"
                        value={newProdMaterial}
                        onChange={(e) => setNewProdMaterial(e.target.value)}
                        placeholder="VD: 100% Cotton Compact chải kỹ"
                        className="w-full px-3 py-2 border rounded-xl"
                      />
                    </div>

                    <div>
                      <label className="font-semibold text-neutral-700 block mb-1">Mô tả sản phẩm</label>
                      <textarea
                        rows={2}
                        value={newProdDesc}
                        onChange={(e) => setNewProdDesc(e.target.value)}
                        placeholder="Mô tả chi tiết form dáng, xuất xứ..."
                        className="w-full px-3 py-2 border rounded-xl"
                      />
                    </div>

                    <div className="pt-2 flex justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setIsAddingProduct(false)}
                        className="px-4 py-2 rounded-xl border text-neutral-600"
                      >
                        Hủy
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 rounded-xl bg-[#1A1A1A] text-white font-bold"
                      >
                        Lưu Sản Phẩm
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* Product Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-neutral-700">
                <thead className="bg-[#FAF8F5] border-y border-neutral-200 text-neutral-600 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="py-3 px-3">Sản Phẩm</th>
                    <th className="py-3 px-3">Mã SKU</th>
                    <th className="py-3 px-3">Danh Mục</th>
                    <th className="py-3 px-3">Giá Bán</th>
                    <th className="py-3 px-3">Tồn Kho</th>
                    <th className="py-3 px-3 text-right">Thao Tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {filteredProducts.map((p) => (
                    <tr key={p.id} className="hover:bg-neutral-50/80 transition-colors">
                      <td className="py-3 px-3 flex items-center gap-3">
                        <img
                          src={p.images[0]}
                          alt={p.name}
                          className="w-12 h-14 rounded-lg object-cover border"
                        />
                        <div>
                          <span className="font-semibold text-neutral-900 block">{p.name}</span>
                          <span className="text-[10px] text-neutral-400">{p.material}</span>
                        </div>
                      </td>

                      <td className="py-3 px-3 font-mono font-bold text-neutral-700">
                        {p.sku}
                      </td>

                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded bg-neutral-100 text-neutral-800 text-[10px] font-medium">
                          {p.categoryName}
                        </span>
                      </td>

                      <td className="py-3 px-3 font-bold text-neutral-900">
                        {formatVND(p.price)}
                      </td>

                      <td className="py-3 px-3">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => onUpdateProduct({ ...p, stock: Math.max(0, p.stock - 1) })}
                            className="w-5 h-5 rounded bg-neutral-200 flex items-center justify-center font-bold"
                          >
                            -
                          </button>
                          <span className={`font-bold ${p.stock <= 20 ? 'text-rose-600' : 'text-neutral-900'}`}>
                            {p.stock}
                          </span>
                          <button
                            type="button"
                            onClick={() => onUpdateProduct({ ...p, stock: p.stock + 1 })}
                            className="w-5 h-5 rounded bg-neutral-200 flex items-center justify-center font-bold"
                          >
                            +
                          </button>
                        </div>
                      </td>

                      <td className="py-3 px-3 text-right space-x-2">
                        <button
                          type="button"
                          onClick={() => onDeleteProduct(p.id)}
                          className="p-1.5 text-neutral-400 hover:text-rose-600 transition-colors"
                          title="Xóa sản phẩm"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* 4. SETTINGS TAB */}
        {activeTab === 'settings' && (
          <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm max-w-3xl space-y-6">
            <div>
              <h2 className="font-serif text-xl font-bold text-neutral-900">
                Thông Tin Cửa Hàng & Ngân Hàng MBBank
              </h2>
              <p className="text-xs text-neutral-500">
                Thiết lập thông tin hiển thị tại cửa hàng, tài khoản MBBank nhận tiền và địa chỉ tại Đà Nẵng
              </p>
            </div>

            <div className="space-y-4 text-xs">
              {/* Personnel */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-neutral-800 block mb-1">Chủ Cửa Hàng</label>
                  <input
                    type="text"
                    value={storeConfig.ownerName}
                    onChange={(e) => onUpdateConfig({ ...storeConfig, ownerName: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl bg-neutral-50 font-semibold"
                  />
                </div>

                <div>
                  <label className="font-bold text-neutral-800 block mb-1">Người Quản Lý Shop</label>
                  <input
                    type="text"
                    value={storeConfig.managerName}
                    onChange={(e) => onUpdateConfig({ ...storeConfig, managerName: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl bg-neutral-50 font-semibold"
                  />
                </div>
              </div>

              {/* Contact */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="font-bold text-neutral-800 block mb-1">Hotline / Zalo</label>
                  <input
                    type="text"
                    value={storeConfig.phone}
                    onChange={(e) => onUpdateConfig({ ...storeConfig, phone: e.target.value, zalo: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl bg-neutral-50 font-semibold font-mono"
                  />
                </div>

                <div>
                  <label className="font-bold text-neutral-800 block mb-1">Facebook Đại Diện</label>
                  <input
                    type="text"
                    value={storeConfig.facebookName}
                    onChange={(e) => onUpdateConfig({ ...storeConfig, facebookName: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl bg-neutral-50 font-semibold"
                  />
                </div>
              </div>

              {/* Address */}
              <div>
                <label className="font-bold text-neutral-800 block mb-1">Địa Chỉ Shop</label>
                <div className="grid grid-cols-3 gap-3">
                  <input
                    type="text"
                    value={storeConfig.address}
                    onChange={(e) => onUpdateConfig({ ...storeConfig, address: e.target.value })}
                    placeholder="Nguyễn Văn Linh"
                    className="w-full px-3 py-2 border rounded-xl bg-neutral-50"
                  />
                  <input
                    type="text"
                    value={storeConfig.ward}
                    onChange={(e) => onUpdateConfig({ ...storeConfig, ward: e.target.value })}
                    placeholder="Nam Dương, Hải Châu"
                    className="w-full px-3 py-2 border rounded-xl bg-neutral-50"
                  />
                  <input
                    type="text"
                    value={storeConfig.city}
                    onChange={(e) => onUpdateConfig({ ...storeConfig, city: e.target.value })}
                    placeholder="TP. Đà Nẵng"
                    className="w-full px-3 py-2 border rounded-xl bg-neutral-50"
                  />
                </div>
              </div>

              {/* Bank Details */}
              <div className="p-4 bg-[#1A1A1A] text-white rounded-2xl border border-[#C9A96E]/30 space-y-3">
                <h4 className="font-bold text-sm text-[#E7DAC7] flex items-center gap-2">
                  <QrCode className="w-4 h-4 text-[#C9A96E]" />
                  <span>Cấu Hình Ngân Hàng Nhận Tiền MBBank</span>
                </h4>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="text-neutral-400 block mb-1">Số Tài Khoản MBBank</label>
                    <input
                      type="text"
                      value={storeConfig.bankAccountNumber}
                      onChange={(e) => onUpdateConfig({ ...storeConfig, bankAccountNumber: e.target.value })}
                      className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-xl text-[#C9A96E] font-bold font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-neutral-400 block mb-1">Tên Chủ Tài Khoản</label>
                    <input
                      type="text"
                      value={storeConfig.bankAccountName}
                      onChange={(e) => onUpdateConfig({ ...storeConfig, bankAccountName: e.target.value.toUpperCase() })}
                      className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-xl text-white font-bold uppercase"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
