import React from 'react';
import { MapPin, Phone, MessageCircle, Clock, ShieldCheck, UserCheck, QrCode } from 'lucide-react';
import { STORE_CONFIG } from '../data/mockData';

export const StoreInfoSection: React.FC = () => {
  return (
    <section className="bg-luxury-pattern border-t border-[#E8E4DC] py-16 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-[#8C6D37]">
            Showroom Mua Sắm Trực Tiếp
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-neutral-900">
            Ghé Thăm LUXURY Tại Đà Nẵng
          </h2>
          <p className="text-sm text-neutral-600 leading-relaxed">
            Tọa lạc tại tuyến đường trung tâm Nguyễn Văn Linh, showroom LUXURY chào đón quý khách đến trực tiếp trải nghiệm chất liệu và dịch vụ tư vấn chuẩn form.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
          {/* Left Column: Showroom Info & Contact (5 cols) */}
          <div className="lg:col-span-5 bg-white/95 backdrop-blur-md p-7 sm:p-9 rounded-3xl border border-[#E8E4DC] shadow-lg flex flex-col justify-between space-y-8">
            <div className="space-y-6">
              <div className="flex items-center gap-3 border-b border-neutral-100 pb-4">
                <div className="w-12 h-12 rounded-2xl bg-[#111111] text-[#C9A96E] flex items-center justify-center font-bold text-sm border border-[#C9A96E]/40">
                  LX
                </div>
                <div>
                  <span className="text-[10px] font-extrabold text-[#8C6D37] uppercase tracking-wider block">
                    Cửa Hàng Thời Trang Cao Cấp
                  </span>
                  <h3 className="font-serif text-xl font-bold text-neutral-900">LUXURY BOUTIQUE</h3>
                </div>
              </div>

              {/* Contact info */}
              <div className="space-y-4 text-xs text-neutral-700">
                <div className="flex items-start gap-3.5">
                  <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#E7DAC7] text-[#8C6D37] mt-0.5">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-neutral-400 block text-[11px]">Địa chỉ showroom:</span>
                    <span className="font-semibold text-neutral-900 text-sm">{STORE_CONFIG.address}, {STORE_CONFIG.ward}, {STORE_CONFIG.city}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#E7DAC7] text-[#8C6D37] mt-0.5">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-neutral-400 block text-[11px]">Hotline tư vấn & đặt hàng:</span>
                    <a href={`tel:${STORE_CONFIG.phone}`} className="font-bold text-neutral-900 text-sm hover:text-[#8C6D37] transition-colors">{STORE_CONFIG.phone}</a>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#E7DAC7] text-[#8C6D37] mt-0.5">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-neutral-400 block text-[11px]">Thời gian mở cửa:</span>
                    <span className="font-semibold text-neutral-900 text-sm">{STORE_CONFIG.openingHours}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="p-2 rounded-xl bg-[#FAF8F5] border border-[#E7DAC7] text-[#8C6D37] mt-0.5">
                    <QrCode className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-neutral-400 block text-[11px]">Thanh toán VietQR:</span>
                    <span className="font-semibold text-neutral-900 text-sm">MBBank: <strong>{STORE_CONFIG.bankAccountNumber}</strong></span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick action buttons */}
            <div className="grid grid-cols-2 gap-3.5 pt-4 border-t border-neutral-100">
              <a
                href={`tel:${STORE_CONFIG.phone}`}
                className="py-3.5 px-4 rounded-2xl bg-[#111111] text-white text-xs font-semibold text-center hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2 shadow-md"
              >
                <Phone className="w-3.5 h-3.5 text-[#C9A96E]" />
                <span>Gọi Hotline</span>
              </a>

              <a
                href={`https://zalo.me/${STORE_CONFIG.zalo}`}
                target="_blank"
                rel="noreferrer"
                className="py-3.5 px-4 rounded-2xl bg-[#0068FF] text-white text-xs font-semibold text-center hover:bg-blue-600 transition-colors flex items-center justify-center gap-2 shadow-md"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Nhắn Zalo</span>
              </a>
            </div>
          </div>

          {/* Right Column: Visual Store Front & Map Card (7 cols) */}
          <div className="lg:col-span-7 bg-[#111111] rounded-3xl overflow-hidden text-white relative shadow-2xl flex flex-col justify-between border border-[#2A2A2A]">
            {/* Visual Store Ambience Image */}
            <div className="relative aspect-[16/9] w-full overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=80"
                alt="Không gian showroom cửa hàng LUXURY"
                className="w-full h-full object-cover opacity-85 hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-[#111111]/40 to-transparent" />
              
              <div className="absolute bottom-4 left-6 right-6 flex items-center justify-between">
                <div>
                  <span className="bg-[#C9A96E] text-[#111111] text-[10px] font-bold px-2.5 py-1 rounded uppercase tracking-wider">
                    LUXURY SHOWROOM ĐÀ NẴNG
                  </span>
                  <h4 className="font-serif text-lg font-bold text-white mt-1">
                    Không gian mua sắm thời trang sang trọng & đẳng cấp
                  </h4>
                </div>
              </div>
            </div>

            {/* Interactive Location Badge */}
            <div className="p-6 sm:p-8 space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
                <div>
                  <h4 className="font-bold text-sm text-[#E7DAC7]">Vị Trí Showroom LUXURY</h4>
                  <p className="text-xs text-neutral-300">
                    Nguyễn Văn Linh, Phường Nam Dương, Quận Hải Châu, Đà Nẵng
                  </p>
                </div>
                <a
                  href={`https://maps.google.com/?q=${encodeURIComponent('Nguyễn Văn Linh, Nam Dương, Đà Nẵng')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-5 py-2.5 bg-white text-neutral-900 hover:bg-neutral-100 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-md"
                >
                  <MapPin className="w-3.5 h-3.5 text-rose-600" />
                  <span>Mở Bản Đồ Chỉ Đường</span>
                </a>
              </div>

              <div className="grid grid-cols-3 gap-3 text-center text-xs text-neutral-300">
                <div className="bg-white/5 p-3 rounded-xl border border-white/10">
                  <span className="font-bold text-white block text-sm">100%</span>
                  <span className="text-[10px] text-neutral-400">Vải may đo cao cấp</span>
                </div>
                <div className="bg-white/5 p-3 rounded-xl border border-white/10">
                  <span className="font-bold text-white block text-sm">2 Tiếng</span>
                  <span className="text-[10px] text-neutral-400">Giao hỏa tốc ĐN</span>
                </div>
                <div className="bg-white/5 p-3 rounded-xl border border-white/10">
                  <span className="font-bold text-white block text-sm">7 Ngày</span>
                  <span className="text-[10px] text-neutral-400">Đổi trả tận tay</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
