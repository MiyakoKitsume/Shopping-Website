import React from 'react';
import { Filter, SlidersHorizontal, RotateCcw, Check, Sparkles } from 'lucide-react';
import { Category, FilterState, Gender, Size } from '../types';
import { formatVND } from '../lib/utils';

interface ProductFilterProps {
  filters: FilterState;
  onFilterChange: (newFilters: FilterState) => void;
  totalResults: number;
}

const CATEGORIES: { id: Category; label: string; icon: string }[] = [
  { id: 'all', label: 'Tất cả', icon: '✨' },
  { id: 't-shirt', label: 'Áo Thun', icon: '👕' },
  { id: 'shirt', label: 'Áo Sơ Mi', icon: '👔' },
  { id: 'jeans', label: 'Quần Jean', icon: '👖' },
  { id: 'trousers', label: 'Quần Tây', icon: '🩳' },
  { id: 'dress', label: 'Váy Đầm', icon: '👗' },
  { id: 'polo', label: 'Áo Polo', icon: '🎽' },
  { id: 'jacket', label: 'Áo Khoác', icon: '🧥' },
];

const GENDERS: { id: Gender; label: string }[] = [
  { id: 'all', label: 'Tất Cả Giới Tính' },
  { id: 'unisex', label: 'Unisex Nam Nữ' },
  { id: 'men', label: 'Thời Trang Nam' },
  { id: 'women', label: 'Thời Trang Nữ' },
];

const SIZES: Size[] = ['S', 'M', 'L', 'XL', 'XXL'];

const POPULAR_COLORS = [
  { name: 'Trắng', hex: '#FFFFFF', border: true },
  { name: 'Đen', hex: '#1C1C1C' },
  { name: 'Xanh', hex: '#1E3F66' },
  { name: 'Be/Nâu', hex: '#C19A6B' },
  { name: 'Xám', hex: '#708090' },
  { name: 'Pastel', hex: '#FAD2E1' },
];

export const ProductFilter: React.FC<ProductFilterProps> = ({
  filters,
  onFilterChange,
  totalResults,
}) => {
  const handleCategoryChange = (category: Category) => {
    onFilterChange({ ...filters, category });
  };

  const handleGenderChange = (gender: Gender) => {
    onFilterChange({ ...filters, gender });
  };

  const handleSizeToggle = (size: Size) => {
    const newSizes = filters.sizes.includes(size)
      ? filters.sizes.filter((s) => s !== size)
      : [...filters.sizes, size];
    onFilterChange({ ...filters, sizes: newSizes });
  };

  const handleResetFilters = () => {
    onFilterChange({
      category: 'all',
      gender: 'all',
      minPrice: 0,
      maxPrice: 1000000,
      sizes: [],
      colors: [],
      searchQuery: '',
      sortBy: 'featured',
      onlyDiscount: false,
      onlyInStock: false,
    });
  };

  const activeFiltersCount = 
    (filters.category !== 'all' ? 1 : 0) +
    (filters.gender !== 'all' ? 1 : 0) +
    (filters.sizes.length > 0 ? 1 : 0) +
    (filters.maxPrice < 1000000 || filters.minPrice > 0 ? 1 : 0) +
    (filters.onlyDiscount ? 1 : 0) +
    (filters.onlyInStock ? 1 : 0);

  return (
    <div className="bg-white rounded-2xl border border-[#EAE6DF] p-4 sm:p-6 shadow-sm space-y-6">
      {/* Category Pills Header */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-bold uppercase tracking-widest text-[#8C6D37]">
            Danh Mục Thời Trang
          </span>
          <span className="text-xs text-neutral-500 font-medium">
            Hiển thị <strong className="text-neutral-900">{totalResults}</strong> sản phẩm
          </span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {CATEGORIES.map((cat) => {
            const isSelected = filters.category === cat.id;
            return (
              <button
                key={cat.id}
                id={`btn-filter-cat-${cat.id}`}
                type="button"
                onClick={() => handleCategoryChange(cat.id)}
                className={`whitespace-nowrap flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold tracking-wide transition-all ${
                  isSelected
                    ? 'bg-[#1A1A1A] text-white shadow-sm'
                    : 'bg-[#F7F5F0] text-neutral-700 hover:bg-[#EAE6DF] hover:text-neutral-900 border border-transparent'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Advanced Filters Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 pt-4 border-t border-neutral-100">
        {/* 1. Target Gender */}
        <div>
          <label className="text-xs font-bold uppercase tracking-wider text-neutral-700 block mb-2">
            Đối tượng
          </label>
          <div className="grid grid-cols-2 gap-1.5">
            {GENDERS.map((g) => (
              <button
                key={g.id}
                id={`btn-filter-gender-${g.id}`}
                type="button"
                onClick={() => handleGenderChange(g.id)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium text-left transition-colors truncate ${
                  filters.gender === g.id
                    ? 'bg-[#8C6D37] text-white font-semibold'
                    : 'bg-neutral-50 text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                {g.label}
              </button>
            ))}
          </div>
        </div>

        {/* 2. Size Selector */}
        <div>
          <label className="text-xs font-bold uppercase tracking-wider text-neutral-700 block mb-2">
            Kích cỡ (Size)
          </label>
          <div className="flex items-center gap-1.5 flex-wrap">
            {SIZES.map((size) => {
              const isSelected = filters.sizes.includes(size);
              return (
                <button
                  key={size}
                  id={`btn-filter-size-${size}`}
                  type="button"
                  onClick={() => handleSizeToggle(size)}
                  className={`w-9 h-9 rounded-lg text-xs font-bold transition-all flex items-center justify-center ${
                    isSelected
                      ? 'bg-[#1A1A1A] text-white ring-2 ring-[#C9A96E]/50'
                      : 'bg-neutral-50 text-neutral-700 hover:bg-neutral-200 border border-neutral-200'
                  }`}
                >
                  {size}
                </button>
              );
            })}
          </div>
        </div>

        {/* 3. Price Bracket Filter */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="text-xs font-bold uppercase tracking-wider text-neutral-700">
              Mức giá tối đa
            </label>
            <span className="text-xs font-bold text-[#8C6D37]">
              {filters.maxPrice >= 1000000 ? 'Tất cả giá' : formatVND(filters.maxPrice)}
            </span>
          </div>
          <input
            id="range-price-filter"
            type="range"
            min="150000"
            max="1000000"
            step="50000"
            value={filters.maxPrice}
            onChange={(e) => onFilterChange({ ...filters, maxPrice: Number(e.target.value) })}
            className="w-full h-1.5 bg-neutral-200 rounded-lg appearance-none cursor-pointer accent-[#8C6D37]"
          />
          <div className="flex justify-between text-[10px] text-neutral-400 mt-1">
            <span>150k</span>
            <span>500k</span>
            <span>1 triệu+</span>
          </div>
        </div>

        {/* 4. Sort Options */}
        <div>
          <label className="text-xs font-bold uppercase tracking-wider text-neutral-700 block mb-2">
            Sắp xếp theo
          </label>
          <select
            id="select-sort-by"
            value={filters.sortBy}
            onChange={(e) => onFilterChange({ ...filters, sortBy: e.target.value as any })}
            className="w-full px-3 py-2 text-xs font-medium bg-neutral-50 border border-neutral-200 rounded-lg outline-none focus:border-[#8C6D37] text-neutral-800"
          >
            <option value="featured">✨ Nổi bật nhất</option>
            <option value="newest">🔥 Hàng mới về</option>
            <option value="best-selling">⭐ Bán chạy nhất</option>
            <option value="price-asc">💰 Giá tăng dần</option>
            <option value="price-desc">💎 Giá giảm dần</option>
          </select>
        </div>
      </div>

      {/* Footer Strip with Quick Filters & Reset */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-neutral-100 text-xs">
        <div className="flex items-center gap-4">
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              id="chk-only-discount"
              type="checkbox"
              checked={filters.onlyDiscount}
              onChange={(e) => onFilterChange({ ...filters, onlyDiscount: e.target.checked })}
              className="w-4 h-4 rounded text-[#8C6D37] focus:ring-[#8C6D37] border-neutral-300 accent-[#8C6D37]"
            />
            <span className="text-neutral-700 font-medium">Đang giảm giá</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              id="chk-only-stock"
              type="checkbox"
              checked={filters.onlyInStock}
              onChange={(e) => onFilterChange({ ...filters, onlyInStock: e.target.checked })}
              className="w-4 h-4 rounded text-[#8C6D37] focus:ring-[#8C6D37] border-neutral-300 accent-[#8C6D37]"
            />
            <span className="text-neutral-700 font-medium">Chỉ còn hàng</span>
          </label>
        </div>

        {activeFiltersCount > 0 && (
          <button
            id="btn-reset-filters"
            type="button"
            onClick={handleResetFilters}
            className="flex items-center gap-1.5 text-neutral-500 hover:text-neutral-900 transition-colors font-medium text-xs px-2.5 py-1 rounded bg-neutral-100 hover:bg-neutral-200"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Xóa bộ lọc ({activeFiltersCount})</span>
          </button>
        )}
      </div>
    </div>
  );
};
