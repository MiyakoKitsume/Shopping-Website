import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, Tag, ShieldCheck } from 'lucide-react';
import { CartItem } from '../types';
import { formatVND } from '../lib/utils';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [couponMessage, setCouponMessage] = useState<{ text: string; isError?: boolean } | null>(null);

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discountAmount = Math.round(subtotal * (discountPercent / 100));
  const shippingFee = subtotal >= 499000 || subtotal === 0 ? 0 : 25000;
  const grandTotal = Math.max(0, subtotal - discountAmount + shippingFee);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const code = couponCode.trim().toUpperCase();
    if (code === 'NHATTUNG10' || code === 'NHAT10' || code === 'TUNG10') {
      setDiscountPercent(10);
      setCouponMessage({ text: 'Áp dụng mã giảm 10% thành công!' });
    } else if (code === 'DANANG50K' && subtotal >= 500000) {
      setDiscountPercent(15);
      setCouponMessage({ text: 'Áp dụng mã tri ân Đà Nẵng giảm 15%!' });
    } else {
      setCouponMessage({ text: 'Mã giảm giá không hợp lệ hoặc đã hết hạn', isError: true });
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/50 backdrop-blur-sm animate-fadeIn">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#8C6D37]" />
              <h2 className="font-serif text-lg font-bold text-neutral-900">
                Giỏ Hàng Của Bạn
              </h2>
              <span className="bg-[#1A1A1A] text-white text-xs font-bold px-2 py-0.5 rounded-full">
                {items.reduce((acc, i) => acc + i.quantity, 0)}
              </span>
            </div>
            <button
              id="btn-close-cart-drawer"
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-full text-neutral-500 hover:text-neutral-900 hover:bg-neutral-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {items.length === 0 ? (
              <div className="text-center py-16 space-y-4">
                <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto text-neutral-400">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="font-bold text-neutral-800 text-base">Giỏ hàng đang trống</h3>
                  <p className="text-xs text-neutral-500 mt-1">
                    Hãy lựa chọn những sản phẩm thời trang ưng ý từ Nhất & Tùng Boutique.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 bg-[#1A1A1A] text-white text-xs font-semibold rounded-full hover:bg-neutral-800 transition-colors inline-block"
                >
                  Khám phá sản phẩm ngay
                </button>
              </div>
            ) : (
              items.map((item, idx) => (
                <div
                  key={`${item.product.id}-${item.selectedSize}-${item.selectedColor.name}-${idx}`}
                  className="flex gap-4 p-3.5 bg-[#FAF8F5] rounded-2xl border border-neutral-200/80 hover:border-[#DFCDB7] transition-all"
                >
                  {/* Thumbnail */}
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-20 h-24 rounded-xl object-cover border border-neutral-200"
                  />

                  {/* Info */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start gap-1">
                        <h4 className="font-medium text-xs sm:text-sm text-neutral-900 line-clamp-1">
                          {item.product.name}
                        </h4>
                        <button
                          type="button"
                          onClick={() => onRemoveItem(idx)}
                          className="text-neutral-400 hover:text-rose-600 transition-colors p-1"
                          title="Xóa khỏi giỏ"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Variant Specs */}
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-neutral-500">
                        <span className="bg-white px-2 py-0.5 rounded border border-neutral-200 font-semibold text-neutral-700">
                          Size {item.selectedSize}
                        </span>
                        <span className="flex items-center gap-1 bg-white px-2 py-0.5 rounded border border-neutral-200">
                          <span
                            className="w-2.5 h-2.5 rounded-full border"
                            style={{ backgroundColor: item.selectedColor.hex }}
                          />
                          <span>{item.selectedColor.name}</span>
                        </span>
                      </div>
                    </div>

                    {/* Price and Quantity controls */}
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-neutral-200/50">
                      <span className="text-xs font-bold text-neutral-900">
                        {formatVND(item.product.price * item.quantity)}
                      </span>

                      <div className="flex items-center border border-neutral-300 rounded-lg bg-white overflow-hidden text-xs">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(idx, Math.max(1, item.quantity - 1))}
                          className="px-2 py-1 hover:bg-neutral-100 text-neutral-600 font-bold"
                        >
                          -
                        </button>
                        <span className="px-2.5 py-1 font-bold text-neutral-800 text-xs">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(idx, item.quantity + 1)}
                          className="px-2 py-1 hover:bg-neutral-100 text-neutral-600 font-bold"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer with Calculations and Checkout */}
          {items.length > 0 && (
            <div className="p-5 border-t border-neutral-200 bg-neutral-50 space-y-4">
              {/* Voucher Input */}
              <form onSubmit={handleApplyCoupon} className="space-y-1">
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      placeholder="Mã voucher (Thử: NHATTUNG10)"
                      className="w-full pl-8 pr-3 py-2 text-xs uppercase bg-white border border-neutral-300 rounded-xl outline-none focus:border-[#8C6D37]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#1A1A1A] text-white text-xs font-semibold rounded-xl hover:bg-neutral-800 transition-colors"
                  >
                    Áp dụng
                  </button>
                </div>
                {couponMessage && (
                  <p className={`text-[11px] font-medium ${couponMessage.isError ? 'text-rose-600' : 'text-emerald-700'}`}>
                    {couponMessage.text}
                  </p>
                )}
              </form>

              {/* Price Details */}
              <div className="space-y-1.5 text-xs text-neutral-600 border-t border-neutral-200 pt-3">
                <div className="flex justify-between">
                  <span>Tạm tính ({items.length} món):</span>
                  <span className="font-semibold text-neutral-800">{formatVND(subtotal)}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>Mã giảm giá ({discountPercent}%):</span>
                    <span>-{formatVND(discountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Phí giao hàng:</span>
                  <span className="font-semibold text-neutral-800">
                    {shippingFee === 0 ? (
                      <span className="text-emerald-700 font-bold">MIỄN PHÍ</span>
                    ) : (
                      formatVND(shippingFee)
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-bold text-neutral-900 pt-2 border-t border-neutral-200">
                  <span>Tổng thanh toán:</span>
                  <span className="text-base text-[#8C6D37]">{formatVND(grandTotal)}</span>
                </div>
              </div>

              {/* Free ship progress */}
              {subtotal < 499000 && (
                <div className="text-[11px] text-neutral-500 bg-white p-2 rounded-lg border border-neutral-200">
                  Mua thêm <strong className="text-neutral-900">{formatVND(499000 - subtotal)}</strong> để được <strong>FREESHIP toàn quốc</strong>!
                </div>
              )}

              {/* Checkout Trigger */}
              <button
                id="btn-drawer-proceed-checkout"
                type="button"
                onClick={() => {
                  onClose();
                  onCheckout();
                }}
                className="w-full py-3.5 px-4 bg-[#1A1A1A] hover:bg-[#333] text-white font-semibold text-xs tracking-wider uppercase rounded-2xl transition-all shadow-lg flex items-center justify-center gap-2"
              >
                <span>Tiến Hành Đặt Hàng & Quét MBBank QR</span>
                <ArrowRight className="w-4 h-4 text-[#C9A96E]" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[10px] text-neutral-400">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Bảo mật thanh toán qua MBBank (Võ Duy Nhất - 0356864672)</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
