import React, { useState } from 'react';
import { Phone, MessageCircle, MapPin, X, ChevronUp, User } from 'lucide-react';
import { STORE_CONFIG } from '../data/mockData';

export const FloatingHotline: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2.5 select-none">
      {/* Expanded Quick Contact Card */}
      {isOpen && (
        <div className="bg-white rounded-3xl p-4 sm:p-5 shadow-2xl border border-neutral-200 w-72 sm:w-80 animate-fadeIn space-y-3.5 text-neutral-800">
          <div className="flex items-center justify-between border-b border-neutral-100 pb-2.5">
            <div>
              <span className="text-[10px] font-extrabold text-[#8C6D37] uppercase tracking-wider block">
                Đường Dây Nóng 24/7
              </span>
              <h4 className="font-bold text-xs sm:text-sm text-neutral-900">
                LUXURY Boutique Đà Nẵng
              </h4>
            </div>
            <button
              id="btn-close-floating-hotline"
              type="button"
              onClick={() => setIsOpen(false)}
              className="p-1 text-neutral-400 hover:text-neutral-700 rounded-full"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Personnel Quick Info */}
          <div className="text-[11px] bg-[#FAF8F5] p-3 rounded-2xl border border-[#EAE6DF] space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-neutral-500">Cửa hàng:</span>
              <strong className="text-neutral-900 font-display tracking-wider">LUXURY BOUTIQUE</strong>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-500">Hotline 24/7:</span>
              <strong className="text-[#8C6D37] font-bold">{STORE_CONFIG.phone}</strong>
            </div>
            <div className="flex items-center gap-1.5 text-neutral-600 pt-1.5 border-t border-neutral-200/60">
              <MapPin className="w-3.5 h-3.5 text-[#8C6D37] flex-shrink-0" />
              <span className="truncate">{STORE_CONFIG.address}, Nam Dương, Đà Nẵng</span>
            </div>
          </div>

          {/* Action Links */}
          <div className="space-y-2">
            {/* 1. Direct Call */}
            <a
              id="link-call-hotline"
              href={`tel:${STORE_CONFIG.phone}`}
              className="flex items-center gap-3 p-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                <Phone className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <span className="text-xs font-bold block">Gọi Hotline 24/7</span>
                <span className="text-[11px] font-mono text-emerald-700">{STORE_CONFIG.phone}</span>
              </div>
            </a>

            {/* 2. Zalo Chat */}
            <a
              id="link-zalo-hotline"
              href={`https://zalo.me/${STORE_CONFIG.zalo}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-3 p-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-800 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-[#0068FF] text-white flex items-center justify-center font-bold text-xs">
                Zalo
              </div>
              <div className="flex-1">
                <span className="text-xs font-bold block">Nhắn Tin Zalo</span>
                <span className="text-[11px] text-blue-700">{STORE_CONFIG.zalo}</span>
              </div>
            </a>

            {/* 3. Facebook Profile */}
            <a
              id="link-fb-hotline"
              href={STORE_CONFIG.facebookUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-3 p-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-[#1877F2] text-white flex items-center justify-center font-bold text-xs">
                f
              </div>
              <div className="flex-1">
                <span className="text-xs font-bold block">Fanpage LUXURY</span>
                <span className="text-[11px] text-neutral-500">Tư vấn chọn size trực tiếp</span>
              </div>
            </a>
          </div>
        </div>
      )}

      {/* Main Floating Trigger Button */}
      <button
        id="btn-toggle-floating-hotline"
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="group relative flex items-center gap-2.5 px-4 py-3 bg-[#1A1A1A] hover:bg-[#333] text-white rounded-full shadow-2xl border-2 border-[#C9A96E]/60 transition-all hover:scale-105 active:scale-95"
      >
        {/* Pulse ring animation */}
        <span className="absolute -top-1 -right-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#C9A96E] opacity-75"></span>
          <span className="relative inline-flex rounded-full h-4 w-4 bg-[#C9A96E]"></span>
        </span>

        <div className="p-1 rounded-full bg-[#C9A96E] text-[#1A1A1A]">
          <Phone className="w-4 h-4 animate-bounce" />
        </div>
        
        <div className="text-left hidden sm:block">
          <span className="text-[10px] uppercase font-bold text-[#E7DAC7] block tracking-wider">
            Hotline Đà Nẵng
          </span>
          <span className="text-xs font-bold font-mono tracking-wide">
            {STORE_CONFIG.phone}
          </span>
        </div>
      </button>
    </div>
  );
};
