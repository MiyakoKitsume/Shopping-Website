import { Product, StoreConfig, Order } from '../types';

export const STORE_CONFIG: StoreConfig = {
  storeName: 'LUXURY',
  ownerName: 'Võ Duy Nhất',
  managerName: 'Võ Duy Nhất',
  phone: '0356864672',
  zalo: '0356864672',
  facebookName: 'Võ Duy Nhất',
  facebookUrl: 'https://facebook.com/duynhatvo',
  address: 'Nguyễn Văn Linh',
  ward: 'Phường Nam Dương, Quận Hải Châu',
  city: 'TP. Đà Nẵng',
  bankName: 'MBBank (Ngân hàng TMCP Quân Đội)',
  bankCode: 'MB',
  bankAccountNumber: '0356864672',
  bankAccountName: 'VÕ DUY NHẤT',
  openingHours: '08:30 - 22:00 (Hàng ngày)',
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    sku: 'NT-TSH-01',
    name: 'Áo Thun Trơn Basic Cotton 100% 250gsm',
    category: 't-shirt',
    categoryName: 'Áo Thun',
    gender: 'unisex',
    price: 189000,
    originalPrice: 250000,
    images: [
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'Trắng Sữa', hex: '#F8F9FA' },
      { name: 'Đen Huyền', hex: '#1A1A1A' },
      { name: 'Be Cát', hex: '#D2B48C' },
      { name: 'Xanh Rêu', hex: '#4A5D4E' }
    ],
    stock: 45,
    description: 'Chất vải Cotton 100% định lượng 250gsm dày dặn, không nhăn, thấm hút mồ hôi tối ưu cho khí hậu Đà Nẵng và Việt Nam. Form suông Regular Fit thoải mái cho cả nam và nữ.',
    material: '100% Premium Cotton Compact chải kỹ',
    careGuide: 'Giặt máy ở nhiệt độ thường, không dùng thuốc tẩy mạnh, phơi bóng râm.',
    isNew: true,
    isBestSeller: true,
    rating: 4.9,
    reviewCount: 128
  },
  {
    id: 'prod-2',
    sku: 'NT-SMI-02',
    name: 'Áo Sơ Mi Lụa Hàn Quốc Cổ V Thanh Lịch',
    category: 'shirt',
    categoryName: 'Áo Sơ Mi',
    gender: 'women',
    price: 295000,
    originalPrice: 380000,
    images: [
      'https://images.unsplash.com/photo-1598554747436-c9293d6a588f?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['S', 'M', 'L'],
    colors: [
      { name: 'Trắng Ngọc Trai', hex: '#FFF8F0' },
      { name: 'Hồng Phấn Pastel', hex: '#FAD2E1' },
      { name: 'Xanh Mint Nhạt', hex: '#D8F3DC' }
    ],
    stock: 28,
    description: 'Mẫu sơ mi lụa mềm mượt, rủ nhẹ nữ tính tôn dáng công sở và dạo phố. Thiết kế cổ V tinh tế vừa quyến rũ vừa sang trọng.',
    material: 'Lụa Tơ Tằm Tổng Hợp Chống Nhăn',
    careGuide: 'Nên giặt tay hoặc dùng túi giặt chế độ nhẹ. Ủi ở nhiệt độ thấp.',
    isNew: true,
    isBestSeller: false,
    rating: 4.8,
    reviewCount: 64
  },
  {
    id: 'prod-3',
    sku: 'NT-JEA-03',
    name: 'Quần Jean Ống Suông Unisex Vintage Denim',
    category: 'jeans',
    categoryName: 'Quần Jean',
    gender: 'unisex',
    price: 360000,
    originalPrice: 450000,
    images: [
      'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1542272604-780c96856592?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Xanh Nhạt Vintage', hex: '#87CEEB' },
      { name: 'Xanh Đậm Indigo', hex: '#1E3F66' },
      { name: 'Đen Khói', hex: '#2B2B2B' }
    ],
    stock: 35,
    description: 'Quần bò denim wash màu cổ điển, form suông rộng che khuyết điểm chân hoàn hảo. Dễ phối cùng áo thun, sơ mi hay croptop.',
    material: '100% Cotton Denim dệt chéo',
    careGuide: 'Lộn trái khi giặt và phơi để giữ màu bền lâu.',
    isNew: false,
    isBestSeller: true,
    rating: 5.0,
    reviewCount: 215
  },
  {
    id: 'prod-4',
    sku: 'NT-POL-04',
    name: 'Áo Polo Nam Vải Cá Sấu Cotton Co Giãn 4 Chiều',
    category: 'polo',
    categoryName: 'Áo Polo',
    gender: 'men',
    price: 245000,
    originalPrice: 320000,
    images: [
      'https://images.unsplash.com/photo-1625910513413-5b8d2d6cfa95?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'Xanh Navy Đậm', hex: '#0B1B3D' },
      { name: 'Đen Tuyển', hex: '#111111' },
      { name: 'Xám Tiêu', hex: '#808080' },
      { name: 'Trắng Tinh', hex: '#FFFFFF' }
    ],
    stock: 50,
    description: 'Áo Polo cổ bẻ phối bo viền tinh xảo, chất cá sấu mắt chim thoáng khí. Phù hợp mặc đi làm, đi chơi hay gặp gỡ đối tác.',
    material: '95% Cotton CVC + 5% Spandex co giãn',
    careGuide: 'Không ngâm lâu trong nước xà phòng, tránh vắt xoắn quá mạnh.',
    isNew: true,
    isBestSeller: true,
    rating: 4.9,
    reviewCount: 96
  },
  {
    id: 'prod-5',
    sku: 'NT-DRS-05',
    name: 'Đầm Hoa Nhí Dáng Suông Nhẹ Nhàng Mùa Hè',
    category: 'dress',
    categoryName: 'Váy Đầm',
    gender: 'women',
    price: 340000,
    originalPrice: 420000,
    images: [
      'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['S', 'M', 'L'],
    colors: [
      { name: 'Vàng Cúc Nhỏ', hex: '#FEE440' },
      { name: 'Xanh Biển Pastel', hex: '#A2D2FF' },
      { name: 'Trắng Kem Hoa', hex: '#FFFBEA' }
    ],
    stock: 19,
    description: 'Đầm voan hoa nhí 2 lớp mềm nhẹ, thiết kế tay bồng tiểu thư duyên dáng cho các buổi hẹn hò, du lịch biển Đà Nẵng.',
    material: 'Chiffon / Voan tơ cao cấp có lót trong',
    careGuide: 'Giặt tay nhẹ nhàng, phơi nơi thoáng gió.',
    isNew: true,
    isBestSeller: false,
    rating: 4.7,
    reviewCount: 42
  },
  {
    id: 'prod-6',
    sku: 'NT-TRU-06',
    name: 'Quần Tây Âu Baggy Cạp Cao Phong Cách Hàn Quốc',
    category: 'trousers',
    categoryName: 'Quần Tây',
    gender: 'unisex',
    price: 310000,
    originalPrice: 390000,
    images: [
      'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Đen Tuyển', hex: '#1C1C1C' },
      { name: 'Xám Ghi Sang Trọng', hex: '#5D647B' },
      { name: 'Nâu Cà Phê', hex: '#4A3728' },
      { name: 'Be Sữa', hex: '#E6D7C3' }
    ],
    stock: 40,
    description: 'Quần tây vải tuyết mưa mềm đứng form, lưng thun co giãn giấu phía sau tạo sự dễ chịu khi ngồi làm việc lâu.',
    material: 'Vải Tuyết Mưa Vitex Cao Cấp',
    careGuide: 'Ủi lộn trái ở nhiệt độ vừa phải, không giặt chung đồ phai màu.',
    isNew: false,
    isBestSeller: true,
    rating: 4.9,
    reviewCount: 178
  },
  {
    id: 'prod-7',
    sku: 'NT-JKT-07',
    name: 'Áo Khoác Blazer Nam Nữ Dáng Rộng Tối Giản',
    category: 'jacket',
    categoryName: 'Áo Khoác',
    gender: 'unisex',
    price: 490000,
    originalPrice: 650000,
    images: [
      'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1548883354-7622d03aca27?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['M', 'L', 'XL'],
    colors: [
      { name: 'Đen Huyền Bí', hex: '#1A1A1A' },
      { name: 'Nâu Tây Camel', hex: '#C19A6B' },
      { name: 'Ghi Xám Khói', hex: '#708090' }
    ],
    stock: 22,
    description: 'Blazer 1 lớp nhẹ mát thích hợp thời tiết 4 mùa tại Việt Nam. Đường may sắc sảo với ve áo cổ điển tinh gọn, tạo vẻ ngoài tri thức, đẳng cấp.',
    material: 'Vải Kaki Tuyết Mịn Cao Cấp',
    careGuide: 'Khuyên dùng giặt khô hoặc giặt hấp để bảo vệ dáng vai áo.',
    isNew: true,
    isBestSeller: true,
    rating: 5.0,
    reviewCount: 89
  },
  {
    id: 'prod-8',
    sku: 'NT-SMI-08',
    name: 'Áo Sơ Mi Nam Đũi Xước Cổ Tàu Thoáng Mát',
    category: 'shirt',
    categoryName: 'Áo Sơ Mi',
    gender: 'men',
    price: 260000,
    originalPrice: 340000,
    images: [
      'https://images.unsplash.com/photo-1603252109303-2751441dd157?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=1000&q=80'
    ],
    sizes: ['M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'Trắng Đũi', hex: '#F5F5F0' },
      { name: 'Xanh Navy Mộc', hex: '#1F2937' },
      { name: 'Be Đũi Tự Nhiên', hex: '#E5DCC5' }
    ],
    stock: 31,
    description: 'Áo sơ mi cổ trụ chất vải đũi tự nhiên tạo cảm giác nhẹ bẫng, mộc mạc, rất hợp với những ngày dạo biển Mỹ Khê hay phố cổ.',
    material: '100% Sợi Đũi Linen Xước Tự Nhiên',
    careGuide: 'Giặt nhẹ tay, phơi trong râm mát.',
    isNew: false,
    isBestSeller: false,
    rating: 4.8,
    reviewCount: 53
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'order-101',
    orderCode: 'NT-DN9821',
    createdAt: '2026-08-24 14:20',
    customerName: 'Trần Minh Hoàng',
    customerPhone: '0905123456',
    customerEmail: 'hoangtran.dn@gmail.com',
    customerAddress: '154 Bạch Đằng, P. Hải Châu 1',
    city: 'TP. Đà Nẵng',
    district: 'Quận Hải Châu',
    note: 'Giao giờ hành chính giúp em',
    items: [
      {
        product: INITIAL_PRODUCTS[0],
        selectedSize: 'L',
        selectedColor: { name: 'Đen Huyền', hex: '#1A1A1A' },
        quantity: 2
      },
      {
        product: INITIAL_PRODUCTS[2],
        selectedSize: 'L',
        selectedColor: { name: 'Xanh Đậm Indigo', hex: '#1E3F66' },
        quantity: 1
      }
    ],
    subtotal: 738000,
    discount: 50000,
    shippingFee: 0,
    totalAmount: 688000,
    paymentMethod: 'mbbank_qr',
    paymentStatus: 'paid',
    shippingStatus: 'shipping',
    bankTransactionCode: 'MB-TX982103'
  },
  {
    id: 'order-102',
    orderCode: 'NT-DN9822',
    createdAt: '2026-08-24 11:45',
    customerName: 'Nguyễn Thị Mai Anh',
    customerPhone: '0935888999',
    customerEmail: 'maianh.nguyen@yahoo.com',
    customerAddress: '235 Lê Duẩn, P. Tân Chính',
    city: 'TP. Đà Nẵng',
    district: 'Quận Thanh Khê',
    items: [
      {
        product: INITIAL_PRODUCTS[1],
        selectedSize: 'M',
        selectedColor: { name: 'Trắng Ngọc Trai', hex: '#FFF8F0' },
        quantity: 1
      },
      {
        product: INITIAL_PRODUCTS[4],
        selectedSize: 'S',
        selectedColor: { name: 'Xanh Biển Pastel', hex: '#A2D2FF' },
        quantity: 1
      }
    ],
    subtotal: 635000,
    discount: 0,
    shippingFee: 0,
    totalAmount: 635000,
    paymentMethod: 'mbbank_qr',
    paymentStatus: 'verified',
    shippingStatus: 'confirmed'
  },
  {
    id: 'order-103',
    orderCode: 'NT-DN9823',
    createdAt: '2026-08-23 18:10',
    customerName: 'Lê Văn Toàn',
    customerPhone: '0988776655',
    customerAddress: '42 Nguyễn Hữu Thọ, P. Hòa Thuận Tây',
    city: 'TP. Đà Nẵng',
    district: 'Quận Hải Châu',
    items: [
      {
        product: INITIAL_PRODUCTS[6],
        selectedSize: 'XL',
        selectedColor: { name: 'Đen Huyền Bí', hex: '#1A1A1A' },
        quantity: 1
      }
    ],
    subtotal: 490000,
    discount: 0,
    shippingFee: 0,
    totalAmount: 490000,
    paymentMethod: 'cod',
    paymentStatus: 'pending',
    shippingStatus: 'delivered'
  }
];
