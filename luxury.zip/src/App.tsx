import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { ProductFilter } from './components/ProductFilter';
import { ProductCard } from './components/ProductCard';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { AuthModal } from './components/AuthModal';
import { WishlistModal } from './components/WishlistModal';
import { AdminDashboard } from './components/AdminDashboard';
import { StoreInfoSection } from './components/StoreInfoSection';
import { FloatingHotline } from './components/FloatingHotline';
import { Footer } from './components/Footer';

import { 
  Product, 
  CartItem, 
  Order, 
  User, 
  FilterState, 
  StoreConfig, 
  Size,
  Category 
} from './types';
import { 
  INITIAL_PRODUCTS, 
  INITIAL_ORDERS, 
  STORE_CONFIG as DEFAULT_STORE_CONFIG 
} from './data/mockData';

export default function App() {
  // App View Mode: 'store' (Customer shopping) | 'admin' (Store management)
  const [currentView, setCurrentView] = useState<'store' | 'admin'>('store');

  // Persistent State
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('nt_fashion_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('nt_fashion_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('nt_fashion_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [wishlist, setWishlist] = useState<Product[]>(() => {
    const saved = localStorage.getItem('nt_fashion_wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('nt_fashion_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [storeConfig, setStoreConfig] = useState<StoreConfig>(() => {
    const saved = localStorage.getItem('nt_fashion_config');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.storeName === 'Nhất & Tùng Fashion Boutique' || !parsed.storeName) {
          return { ...DEFAULT_STORE_CONFIG, ...parsed, storeName: 'LUXURY', ownerName: 'Võ Duy Nhất', managerName: 'Võ Duy Nhất' };
        }
        return { ...DEFAULT_STORE_CONFIG, ...parsed };
      } catch (e) {
        return DEFAULT_STORE_CONFIG;
      }
    }
    return DEFAULT_STORE_CONFIG;
  });

  // Modals state
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);

  // Filter & Search State
  const [filters, setFilters] = useState<FilterState>({
    category: 'all',
    gender: 'all',
    minPrice: 0,
    maxPrice: 1000000,
    sizes: [],
    colors: [],
    searchQuery: '',
    sortBy: 'featured',
    onlyDiscount: false,
    onlyInStock: false,
  });

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('nt_fashion_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('nt_fashion_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('nt_fashion_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  useEffect(() => {
    localStorage.setItem('nt_fashion_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('nt_fashion_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('nt_fashion_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('nt_fashion_config', JSON.stringify(storeConfig));
  }, [storeConfig]);

  // Cart Handlers
  const handleAddToCart = (product: Product, size: Size, color: { name: string; hex: string }, quantity: number) => {
    setCartItems((prev) => {
      const existingIndex = prev.findIndex(
        (item) => item.product.id === product.id && item.selectedSize === size && item.selectedColor.name === color.name
      );
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += quantity;
        return updated;
      }
      return [...prev, { product, selectedSize: size, selectedColor: color, quantity }];
    });
  };

  const handleQuickAddToCart = (product: Product) => {
    const defaultSize = product.sizes[0] || 'M';
    const defaultColor = product.colors[0] || { name: 'Mặc định', hex: '#000000' };
    handleAddToCart(product, defaultSize, defaultColor, 1);
    setIsCartOpen(true);
  };

  const handleBuyNow = (product: Product, size: Size, color: { name: string; hex: string }, quantity: number) => {
    handleAddToCart(product, size, color, quantity);
    setSelectedProduct(null);
    setIsCheckoutOpen(true);
  };

  const handleUpdateCartQuantity = (index: number, newQty: number) => {
    setCartItems((prev) => {
      const updated = [...prev];
      if (newQty <= 0) {
        return updated.filter((_, i) => i !== index);
      }
      updated[index].quantity = newQty;
      return updated;
    });
  };

  const handleRemoveCartItem = (index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
  };

  // Wishlist Handlers
  const handleToggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        return prev.filter((p) => p.id !== product.id);
      }
      return [...prev, product];
    });
  };

  // Order Placement Success
  const handleOrderSuccess = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);
    // Clear cart
    setCartItems([]);
  };

  // Admin Management Handlers
  const handleUpdateProduct = (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
  };

  const handleAddProduct = (newProd: Product) => {
    setProducts((prev) => [newProd, ...prev]);
  };

  const handleDeleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const handleUpdateOrderStatus = (orderId: string, paymentStatus: any, shippingStatus: any) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, paymentStatus, shippingStatus } : ord))
    );
  };

  // Filtered and Sorted Products computation
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Category filter
      if (filters.category !== 'all' && p.category !== filters.category) {
        return false;
      }
      // Gender filter
      if (filters.gender !== 'all' && p.gender !== filters.gender && p.gender !== 'unisex') {
        return false;
      }
      // Price filter
      if (p.price > filters.maxPrice || p.price < filters.minPrice) {
        return false;
      }
      // Size filter
      if (filters.sizes.length > 0) {
        const hasSize = filters.sizes.some((s) => p.sizes.includes(s));
        if (!hasSize) return false;
      }
      // Only Discount
      if (filters.onlyDiscount && !p.originalPrice) {
        return false;
      }
      // Only In Stock
      if (filters.onlyInStock && p.stock <= 0) {
        return false;
      }
      // Search query
      if (filters.searchQuery.trim()) {
        const q = filters.searchQuery.toLowerCase().trim();
        const matchesName = p.name.toLowerCase().includes(q);
        const matchesSku = p.sku.toLowerCase().includes(q);
        const matchesCat = p.categoryName.toLowerCase().includes(q);
        const matchesDesc = p.description.toLowerCase().includes(q);
        if (!matchesName && !matchesSku && !matchesCat && !matchesDesc) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'newest') return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
      if (filters.sortBy === 'best-selling') return (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0);
      if (filters.sortBy === 'price-asc') return a.price - b.price;
      if (filters.sortBy === 'price-desc') return b.price - a.price;
      return 0; // featured default
    });
  }, [products, filters]);

  return (
    <div className="min-h-screen flex flex-col bg-luxury-pattern text-neutral-900 font-sans selection:bg-[#C9A96E]/30 selection:text-[#8C6D37]">
      {/* Universal Header */}
      <Header
        currentView={currentView}
        onViewChange={(view) => setCurrentView(view)}
        cartItems={cartItems}
        wishlist={wishlist}
        currentUser={currentUser}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onLogout={() => setCurrentUser(null)}
        searchQuery={filters.searchQuery}
        onSearchChange={(query) => setFilters((prev) => ({ ...prev, searchQuery: query }))}
        onCategorySelect={(cat) => setFilters((prev) => ({ ...prev, category: cat }))}
      />

      {/* Main View Router: Storefront vs Admin Management Dashboard */}
      {currentView === 'admin' ? (
        <AdminDashboard
          products={products}
          orders={orders}
          storeConfig={storeConfig}
          onUpdateProduct={handleUpdateProduct}
          onAddProduct={handleAddProduct}
          onDeleteProduct={handleDeleteProduct}
          onUpdateOrderStatus={handleUpdateOrderStatus}
          onUpdateConfig={setStoreConfig}
          onBackToStore={() => setCurrentView('store')}
        />
      ) : (
        <main className="flex-grow space-y-12">
          {/* Hero Editorial Banner */}
          <HeroBanner
            onExplore={() => {
              const el = document.getElementById('section-products');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            onSelectCategory={(cat: Category) => {
              setFilters((prev) => ({ ...prev, category: cat }));
              const el = document.getElementById('section-products');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
          />

          {/* Product Catalog Section */}
          <section id="section-products" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
            {/* Filter Toolbar */}
            <ProductFilter
              filters={filters}
              onFilterChange={setFilters}
              totalResults={filteredProducts.length}
            />

            {/* Products Grid */}
            {filteredProducts.length === 0 ? (
              <div className="text-center py-20 bg-white rounded-3xl border border-neutral-200 p-8 space-y-4">
                <div className="w-16 h-16 rounded-full bg-neutral-100 flex items-center justify-center mx-auto text-neutral-400">
                  🔍
                </div>
                <h3 className="font-bold text-lg text-neutral-800">
                  Không tìm thấy sản phẩm phù hợp
                </h3>
                <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                  Hãy thử thay đổi từ khóa tìm kiếm hoặc bấm nút xóa bộ lọc để xem lại tất cả sản phẩm.
                </p>
                <button
                  type="button"
                  onClick={() =>
                    setFilters({
                      category: 'all',
                      gender: 'all',
                      minPrice: 0,
                      maxPrice: 1000000,
                      sizes: [],
                      colors: [],
                      searchQuery: '',
                      sortBy: 'featured',
                      onlyDiscount: false,
                      onlyInStock: false,
                    })
                  }
                  className="px-5 py-2.5 bg-[#1A1A1A] text-white text-xs font-semibold rounded-full hover:bg-neutral-800 transition-colors inline-block"
                >
                  Xem Tất Cả Sản Phẩm
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 sm:gap-8">
                {filteredProducts.map((prod) => (
                  <ProductCard
                    key={prod.id}
                    product={prod}
                    isWishlisted={wishlist.some((w) => w.id === prod.id)}
                    onToggleWishlist={handleToggleWishlist}
                    onQuickView={(p) => setSelectedProduct(p)}
                    onQuickAddToCart={handleQuickAddToCart}
                  />
                ))}
              </div>
            )}
          </section>

          {/* Physical Showroom & Contact Showcase Section */}
          <StoreInfoSection />
        </main>
      )}

      {/* Product Quick View & Buying Modal */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
        isWishlisted={selectedProduct ? wishlist.some((w) => w.id === selectedProduct.id) : false}
        onToggleWishlist={handleToggleWishlist}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onCheckout={() => setIsCheckoutOpen(true)}
      />

      {/* Checkout & MBBank VietQR Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cartItems}
        currentUser={currentUser}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* Authentication Modal (Google, Facebook, Email) */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        currentUser={currentUser}
        onLoginSuccess={(user) => setCurrentUser(user)}
        onLogout={() => setCurrentUser(null)}
      />

      {/* Wishlist Modal */}
      <WishlistModal
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        items={wishlist}
        onRemoveWishlist={handleToggleWishlist}
        onQuickAddToCart={handleQuickAddToCart}
      />

      {/* Responsive Floating Hotline Widget */}
      <FloatingHotline />

      {/* Luxury Footer */}
      <Footer />
    </div>
  );
}
