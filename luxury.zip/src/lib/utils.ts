import { STORE_CONFIG } from '../data/mockData';

export function formatVND(amount: number): string {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0,
  }).format(amount).replace('₫', '₫');
}

/**
 * Generate official VietQR URL for MBBank
 * Format: https://img.vietqr.io/image/<BANK_ID>-<ACCOUNT_NO>-<TEMPLATE>.png?amount=<AMOUNT>&addInfo=<DESCRIPTION>&accountName=<ACCOUNT_NAME>
 */
export function getVietQRUrl(amount: number, orderCode: string, template: 'compact2' | 'qr_only' | 'compact' = 'compact2'): string {
  const bankId = 'MB'; // MBBank code
  const accountNo = STORE_CONFIG.bankAccountNumber;
  const accountName = encodeURIComponent(STORE_CONFIG.bankAccountName);
  const memo = encodeURIComponent(`THANHTOAN ${orderCode}`);
  
  return `https://img.vietqr.io/image/${bankId}-${accountNo}-${template}.png?amount=${Math.round(amount)}&addInfo=${memo}&accountName=${accountName}`;
}

export function generateOrderCode(): string {
  const randomDigits = Math.floor(1000 + Math.random() * 9000);
  return `NT-DN${randomDigits}`;
}
